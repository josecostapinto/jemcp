# vestas-planoftheday
Vestas Capacity Plan of the Day and Plan of the Week
