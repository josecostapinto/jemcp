sap.ui.define(
    ['sap/m/PlanningCalendar'],
    function(PlanningCalendar) {
        return PlanningCalendar.extend("plancalendar.controls.CustomPlanningCalendar",{
        	
        	renderer: "sap.m.PlanningCalendarRenderer",
        	
            _handleTodayPress:function (oEvent) {
				var oDate = new Date(),
					oStartDate;
					
				oDate = this._getMonday(oDate);
				this.setStartDate(oDate);
				this.fireStartDateChange();
			},
			
			_getMonday: function (oDate) {
				var sDay = oDate.getDay(),
					iDiff = oDate.getDate() - sDay + (sDay == 0 ? -6 : 1);
				return new Date(oDate.setDate(iDiff));
			},
            
        });
    }
);