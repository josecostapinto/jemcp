/*global moment, _ */
sap.ui.define([
	"../libs/lodash.min",
	"../libs/moment-with-locales.min",
	"./LocalDataPersistence",
	"./BackendData",
	"./ServiceOperations",
	"./Notifications",
	"./Workcenters"
], function(NameToAvoidNamingConflictsLodash, NameToAvoidNamingConflictsMoment, LocalDataPersistence, BackendData, ServiceOperations, Notifications, Workcenters) {
    "use strict";

    return {
    	initializeData: function(oView) {
    		return new Promise(function(fResolve, fReject) {
    			var oViewModel = oView.getModel("viewModel");
    			var oBackendModel = oView.getModel("backend");
    			LocalDataPersistence.getUserSettings(oView).then(function(oUserSettings) {
	    			if (oUserSettings) {
	    				oViewModel.setProperty("/UserSettings", oUserSettings);
	    				oViewModel.setProperty("/IsDataInitialized", true);
	    				this._fetchBackendData(oBackendModel, oViewModel, oUserSettings, new Date());
						fResolve(true);
					} else {
						fResolve(false);
					}
	    		}.bind(this));
    		}.bind(this));
    		
    	},
    	
    	getServiceOperationsForEquipment: function(oBackendModel, sEquipment) {
    		return new Promise(function(fResolve, fReject) {
    			BackendData
    				.getServiceOperationsForEquipment(oBackendModel, sEquipment)
    				.then(function(oResponse) { 
    					fResolve(oResponse.results); 
    				}, fReject);
    		});
    	},
    	
    	saveSettings: function(oSettings) {
    		return LocalDataPersistence.saveUserSettings(oSettings);
    	},
    	
    	clearSettings: function() {
    		return LocalDataPersistence.clearUserSettings();
    	},
    	
    	getLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation) {
    		return LocalDataPersistence.getLocalChangesForServiceOperation(oViewModel, sServiceOrderNumber, sOperation);
    	},
    	
    	getLocalChangesForNotifications: function(oViewModel, sNotification) {
    		return LocalDataPersistence.getLocalChangesForNotifications(oViewModel, sNotification);
    	},
    	
    	getLocalChangesUnplannedTasks: function(oViewModel) {
    		return LocalDataPersistence.getLocalChangesUnplannedTasks(oViewModel);
    	},
    	
    	saveLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges) {
    		return LocalDataPersistence.saveLocalChangesForServiceOperation(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges);
    	},
    	
    	saveLocalChangesForNotification: function(oViewModel, oNotification, oLocalChanges) {
    		return LocalDataPersistence.saveLocalChangesForNotification(oViewModel, oNotification, oLocalChanges);
    	},
    	
    	saveLocalChangesUnplannedTasks: function(oViewModel, aUnplanned) {
    		return LocalDataPersistence.saveLocalChangesUnplannedTasks(oViewModel, aUnplanned);
    	},
    	
    	removeLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges) {
    		return LocalDataPersistence.removeLocalChangesForServiceOperation(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges);
    	},
    	
    	removeLocalChangesForNotification: function(oViewModel, sNotification, oLocalChanges) {
    		return LocalDataPersistence.removeLocalChangesForNotification(oViewModel, sNotification, oLocalChanges);
    	},
    	
    	_mapNotification: function(oLocalSOChanges, oNotification, oLocalNotifChangess) {
    		return LocalDataPersistence._mapNotification(oLocalSOChanges, oNotification, oLocalNotifChangess);
    	},
    	
    	
    	getInitialUsersettings: function () {
    		return {
    			LocalChanges: {},
    			SiteName: null,
    			Sites: [],
    			Workcenters: [],
    			SavedSites: []
    		};
    	},
    	
    	lookupSiteId: function(oBackendModel, sSiteId) {
    		return new Promise(function(fResolve, fReject) {
    			BackendData
    				.lookupSiteId(oBackendModel, sSiteId)
    				.then(function(oResponse) { 
    					fResolve(oResponse.results); 
    				}, fReject);
    		});
    	},
    	
    	lookupWorkcenterId: function(oBackendModel, sWorkcenterId) {
    		return new Promise(function(fResolve, fReject) {
    			BackendData
    				.lookupWorkcenterId(oBackendModel, sWorkcenterId)
    				.then(function(oResponse) { 
    					fResolve(oResponse.results); 
    				}, fReject);
    		});
    	},
    	
    	lookupServiceTeam: function(oBackendModel, sWorkcenterId, dDate) {
    		return new Promise(function(fResolve, fReject) {
    			BackendData
    				.lookupServiceTeam(oBackendModel, sWorkcenterId, dDate)
    				.then(function(oResponse) { 
    					fResolve(oResponse.results); 
    				}, fReject);
    		});
    	},
    	
    	reloadWeeklyServiceOperations: function(oViewModel, oBackendModel) {
    		var dDate = oViewModel.getProperty("/Data/TodaysDate");
    		var dStartDate = oViewModel.getProperty("/Data/StartDate");
    		var dEndDate = oViewModel.getProperty("/Data/EndDate");
    		var oUserSettings = oViewModel.getProperty("/UserSettings");
    		if (!moment(dDate).isBetween(dStartDate, dEndDate)) {
    			return this._fetchBackendDataForDay(oBackendModel, oViewModel, oUserSettings, dDate);
    		}
    		var fHoursPerDay = oUserSettings.HoursPerDay ? oUserSettings.HoursPerDay : 7.0;
    		
    		var aServiceOperations = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/original");
    		var aServiceOperationsWC = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/originalWc");
    		
    		var aNotifications = oViewModel.getProperty("/Data/Notifications/original"); 
    		// var aChangedNotifications = oViewModel.getProperty("/oUserSettings.LocalChanges.Notifications
    		var aChangedServiceOrders = oUserSettings.LocalChanges ? oUserSettings.LocalChanges.ServiceOperations : undefined;
    		var aMerged = ServiceOperations.mergeWithLocalChanges(_.cloneDeep(aServiceOperations), aChangedServiceOrders, oViewModel.getProperty("/Data/AvailableWorkcenters"));
    		var aMergedWC = ServiceOperations.mergeWithLocalChanges(_.cloneDeep(aServiceOperationsWC), aChangedServiceOrders, oViewModel.getProperty("/Data/AvailableWorkcenters"));
    		ServiceOperations.splitTeamArray(aMerged);
			var aMappedPerTurbine = ServiceOperations.perTurbine(aMerged, fHoursPerDay);
			var aMappedPerWorkcenter = ServiceOperations.perWorkcenter(aMergedWC, fHoursPerDay);
			aMappedPerWorkcenter = ServiceOperations.setOriginalWorkcenter(aMergedWC,aMappedPerWorkcenter);
			var aPotd = ServiceOperations.perDay(aMerged, dDate, fHoursPerDay);
			var aPotdWC = ServiceOperations.perDay(aMergedWC, dDate, fHoursPerDay);
			var aCustomers = ServiceOperations.getCustomers(aMerged);
			var aMovedFromDay = ServiceOperations.movedFromDay(aMerged, dDate);
			var aMovedFromDayWC = ServiceOperations.movedFromDay(aMergedWC, dDate);
			var aChangedNotifications = oUserSettings.LocalChanges ? oUserSettings.LocalChanges.Notifications : undefined;
			var aNotificationsNotAdded = Notifications.extractNotAdded(_.cloneDeep(aNotifications), aChangedNotifications);
			var aUnplanned = LocalDataPersistence.getLocalChangesUnplannedTasksForDate(oViewModel, dDate);
			ServiceOperations.splitTeamArray(aUnplanned);
			var aChanged = _.union(_.filter(aPotd, 'HasChanges'), aMovedFromDay);
			var aChangedWC = _.union(_.filter(aPotdWC, 'HasChanges'), aMovedFromDayWC);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/perTurbine", aMappedPerTurbine);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/perWorkcenter", aMappedPerWorkcenter);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/potd", aPotd);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/potdWc", aPotdWC);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/customers", aCustomers);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/movedFromDay", aMovedFromDay);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/movedFromDayWc", aMovedFromDayWC);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/changedFromDay", aChanged);
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/changedFromDayWc", aChangedWC);
			oViewModel.setProperty("/Data/UnplannedForToday", _.cloneDeep(aUnplanned));
			oViewModel.setProperty("/Data/Notifications/notAdded", aNotificationsNotAdded);
    	},
    	
    	_fetchBackendData: function(oBackendModel, oViewModel, oUserSettings) {
    		var dDate = new Date();
    		return this._fetchBackendDataForDay(oBackendModel, oViewModel, oUserSettings, dDate);
    	},
    	
    	_fetchBackendDataForDay: function(oBackendModel, oViewModel, oUserSettings, dDate) {
    		return new Promise(function(fResolve, fReject) {
    			dDate.setHours(parseInt('00'));
    			dDate.setMinutes(parseInt('00'));
    			dDate.setSeconds(parseInt('00'));
				var dStartDate = new Date(dDate);
				dStartDate.setDate(dStartDate.getDate() - 7);
				var dEndDate = new Date(dDate);
				dEndDate.setDate(dEndDate.getDate() + 3 * 7);
				var fHoursPerDay = oUserSettings.HoursPerDay ? oUserSettings.HoursPerDay : 7.0;
    			
    			// 1. Initialize model
    			var aUnplanned = _.cloneDeep(LocalDataPersistence.getLocalChangesUnplannedTasksForDate(oViewModel, dDate));
    			ServiceOperations.splitTeamArray(aUnplanned);
    			oViewModel.setProperty("/Data", {
    				Notifications: { loading: true, original: [], perTurbine: [], perWorkcenter: [], potd: [], notAdded: [] },
    				ServiceOperationsFromDateRange: { loading: true, original: [], originalWc: [], perTurbine: [], perWorkcenter: [], potd: [], 
    				potdWc: [], customers: [] },
    				IncompleteTasks: { loading: true, tasks: [] },
    				UnplannedForToday: aUnplanned,
					TodaysDate: dDate,
					StartDate: dStartDate,
					EndDate: dEndDate,
					AvailableWorkcenters: Workcenters.padWithGroups(oUserSettings.Workcenters)
    			});
    			
    			// 2. Start calls
    			var oNotifPromise = BackendData.getNotifications(oBackendModel, oUserSettings.Sites);
    			var oSODateRange = BackendData.getServiceOperationsForDateRange(oBackendModel, oUserSettings.Sites, dStartDate, dEndDate);
    			
    			// var oSODateRangeWC = BackendData.getServiceOperationsPerWorkcenterForDateRange(oBackendModel, oUserSettings.Workcenters, dStartDate, dEndDate);
    			var oIncompleteSO = BackendData.getIncompletedTasks(oBackendModel, oUserSettings.Sites, dDate);
    			
    			// 3. Set data returned
    			oNotifPromise.then(function(aNotificationsResponse) {
    				var aNotifications = aNotificationsResponse.results;
					aNotifications && aNotifications.forEach(function(oNotification) {
						if (oNotification.Team && oNotification.Team.split(",").length > 5) {
			    			oNotification.Team = "";
			    		}
					}.bind(this));
    				var aChangedNotifications = oUserSettings.LocalChanges ? oUserSettings.LocalChanges.Notifications : undefined;
    				//var aMerged = Notifications.mergeWithLocalChanges(_.cloneDeep(aNotifications), aChangedNotifications);

					// NOTE!!! ONLY changed/added notifications will be displayed in day and week plan
					// TODO: implement these:
    				var aNotificationsMappedPerTurbine = []; // ServiceOperations.perTurbine(aMerged);
					var aNotificationsMappedPerWorkcenter = [];  // ServiceOperations.perWorkcenter(aMerged);
					var aNotificationsPotd = []; // ServiceOperations.perDay(aMerged, dDate);
					var aNotificationsNotAdded = Notifications.extractNotAdded(_.cloneDeep(aNotifications), aChangedNotifications);

    				oViewModel.setProperty("/Data/Notifications", {
    					loading: false,
    					original: aNotifications,
						perTurbine: aNotificationsMappedPerTurbine,
						perWorkcenter: aNotificationsMappedPerWorkcenter,
						potd: aNotificationsPotd,
    					notAdded: aNotificationsNotAdded   
	    			});
    			}, this._handleError);
    			
    			oSODateRange.then(function(oResponse) {
    				var aServiceOperations = oResponse.results;
    				_.forEach(aServiceOperations, function(oServiceOperation) {
						oServiceOperation.EarliestStartDate.setHours(parseInt('00'));
						if (oServiceOperation.Team.split(",").length > 5) {
			    			oServiceOperation.Team = "";
			    		}
					});
    				var aChangedServiceOrders = oUserSettings.LocalChanges ? oUserSettings.LocalChanges.ServiceOperations : undefined;
    				var aMerged = ServiceOperations.mergeWithLocalChanges(_.cloneDeep(aServiceOperations), aChangedServiceOrders, oViewModel.getProperty("/Data/AvailableWorkcenters"));
    				ServiceOperations.splitTeamArray(aMerged);
    				var aMappedPerTurbine = ServiceOperations.perTurbine(aMerged, fHoursPerDay);
					var aPotd = ServiceOperations.perDay(aMerged, dDate, fHoursPerDay);
					var aMovedFromDay = ServiceOperations.movedFromDay(aMerged, dDate);
					var aCustomers = ServiceOperations.getCustomers(aMerged);
					var aChanged = _.union(_.filter(aPotd, 'HasChanges'), aMovedFromDay);
    				oViewModel.setProperty("/Data/ServiceOperationsFromDateRange", {
						loading: false,
						original: aServiceOperations,
						perTurbine: aMappedPerTurbine,
						potd: aPotd,
						customers: aCustomers,
						movedFromDay: aMovedFromDay,
						changedFromDay: aChanged
	    			});
	    			
	    			var oSODateRangeWC = BackendData.getServiceOperationsPerWorkcenterForDateRange(oBackendModel, oUserSettings.Workcenters, dStartDate, dEndDate);
    				oSODateRangeWC.then(function(oResponse) {
	    				var aServiceOperations = oResponse.results;
	    				_.forEach(aServiceOperations, function(oServiceOperation) {
							oServiceOperation.EarliestStartDate.setHours(parseInt('00'));
							if (oServiceOperation.Team.split(",").length > 5) {
			    				oServiceOperation.Team = "";
			    			}
						}.bind(this));
	    				var aChangedServiceOrders = oUserSettings.LocalChanges ? oUserSettings.LocalChanges.ServiceOperations : undefined;
	    				var aMerged = ServiceOperations.mergeWithLocalChanges(_.cloneDeep(aServiceOperations), aChangedServiceOrders, oViewModel.getProperty("/Data/AvailableWorkcenters"));
	    				ServiceOperations.splitTeamArray(aMerged);
	    				var aServiceOperationsTurbine = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/original");
	    				var aMappedPerTurbine = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/perTurbine");
	    				var aPotdTurbine = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/potd");
						var aMappedPerWorkcenter = ServiceOperations.perWorkcenter(aMerged, fHoursPerDay);
						aMappedPerWorkcenter = ServiceOperations.setOriginalWorkcenter(aMerged,aMappedPerWorkcenter);
						var aPotd = ServiceOperations.perDay(aMerged, dDate, fHoursPerDay);
						var aMovedFromDay = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/movedFromDay");
						var aMovedFromDayWC = ServiceOperations.movedFromDay(aMerged, dDate);
						var aChanged = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/changedFromDay");
						var aChangedWC = _.union(_.filter(aPotd, 'HasChanges'), aMovedFromDayWC);
						var aCustomers = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/customers");
	    				oViewModel.setProperty("/Data/ServiceOperationsFromDateRange", {
							loading: false,
							original: aServiceOperationsTurbine,
							originalWc: aServiceOperations,
							perTurbine: aMappedPerTurbine,
							perWorkcenter: aMappedPerWorkcenter,
							potd: aPotdTurbine,
							potdWc: aPotd,
							customers: aCustomers,
							movedFromDay: aMovedFromDay,
							changedFromDay: aChanged,
							movedFromDayWc: aMovedFromDayWC,
							changedFromDayWc: aChangedWC
		    			});
	    			
	    			});
    			}, this._handleError);
    			
    			oIncompleteSO.then(function(oResponse) {
    				var aServiceOperations = oResponse.results;
    				
    				oViewModel.setProperty("/Data/IncompleteTasks", {
						loading: false,
						tasks: aServiceOperations
	    			});
    			
    			}, this._handleError);
    			
    		}.bind(this));
    	},
    	
    	_handleError: function(sErrorMessage) {
    		jQuery.sap.log.error("[DataHandler] Error in backend call: " + sErrorMessage);
    	}
    };
});
