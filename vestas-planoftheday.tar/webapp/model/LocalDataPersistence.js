/*global moment, _ */
sap.ui.define([
	"sap/m/MessageBox",
	"../libs/lodash.min",
	"../libs/moment-with-locales.min"
], function(MessageBox, NameToAvoidNamingConflictsLodash, NameToAvoidNamingConflictsMoment) {
    "use strict";

    return {
    	getUserSettings: function(oView) {
    		var fnResolve = function (fResolve, fReject) {
    			this._initializePersonalizationContainer().then(function() {
    				if (this.oContainer) {
    					var oUserSettings = this.oContainer.getItemValue("UserSettings");
    					fResolve(oUserSettings);
    				} else {
    					fReject(false);
    				}
    			}.bind(this),
    			fReject);
    		};
    		return new Promise(fnResolve.bind(this)) ;
    	},
    	
    	saveUserSettings: function(oSettings) {
    		var fnResolve = function (fResolve, fReject) {
    			this._initializePersonalizationContainer().then(function() {
    				this.oContainer.setItemValue("UserSettings", oSettings);
    				this.oContainer.save().fail(function() {
    					jQuery.sap.log.error("Saving personalization data failed.");
						MessageBox.show(
							"Saving session data failed.", {
								icon: MessageBox.Icon.ERROR,
								title: "Error",
								actions: [MessageBox.Action.OK]
							});
						fReject(false);
    				})
    				.done(function() { fResolve(); });
    			}.bind(this),
    			fReject);
    		};
    		return new Promise(fnResolve.bind(this)) ;
    	},
    	
    	clearUserSettings: function() {
    		return this.saveUserSettings(null);
    	},
    	
    	getLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation) {
    		var aServiceOperations = oViewModel.getProperty("/UserSettings/LocalChanges/ServiceOperations");
    		if (aServiceOperations) {
    			var oServiceOrder =  _.find(aServiceOperations, function(oItem) {
    				return oItem.OrderId === sServiceOrderNumber && oItem.OperationId === sOperation;
    			});
    			if (oServiceOrder) {
    				return oServiceOrder;
    			}
    		}
    		return {
    			OrderId: sServiceOrderNumber,
    			OperationId: sOperation
    		};
    	},
    	
    	getLocalChangesForNotifications: function(oViewModel, sNotification) {
    		var aNotifications = oViewModel.getProperty("/UserSettings/LocalChanges/Notifications");
    		if (aNotifications) {
    			var oNotification =  _.find(aNotifications, function(oItem) {
    				return oItem.NotificationId === sNotification;
    			});
    			if (oNotification) {
    				return oNotification;
    			}
    		}
    		return {
    			NotificationId: sNotification
    		};
    	},
    	
    	saveLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges) {
    		var aServiceOperations = oViewModel.getProperty("/UserSettings/LocalChanges/ServiceOperations");
    		if (aServiceOperations) {
    			var iIndex = _.findIndex(aServiceOperations, {OrderId: sServiceOrderNumber, OperationId: sOperation});
    			if (iIndex >= 0) {
    				aServiceOperations.splice(iIndex, 1, oLocalChanges);
    			} else {
    				aServiceOperations.push(oLocalChanges);
    			}
    			oViewModel.setProperty("/UserSettings/LocalChanges/ServiceOperations", aServiceOperations);
    		} else {
    			if (oViewModel.getProperty("/UserSettings/LocalChanges") === undefined) {
    				oViewModel.setProperty("/UserSettings/LocalChanges", {});
    			}
    			oViewModel.setProperty("/UserSettings/LocalChanges/ServiceOperations", [oLocalChanges]);
    		}
    		return this.saveUserSettings(oViewModel.getProperty("/UserSettings"));
    	},
    	
    	saveLocalChangesForNotification: function(oViewModel, oNotification, oLocalChanges) {
    		
    		var aNotifications = oViewModel.getProperty("/UserSettings/LocalChanges/Notifications");
    		if (aNotifications) {
    			var iIndex = _.findIndex(aNotifications, {NotificationId: oLocalChanges.NotificationId});
    			if (iIndex >= 0) {
    				aNotifications.splice(iIndex, 1, oLocalChanges);
    			} else {
    				aNotifications.push(oLocalChanges);
    			}
    			oViewModel.setProperty("/UserSettings/LocalChanges/Notifications", aNotifications);
    		} else {
    			oViewModel.setProperty("/UserSettings/LocalChanges/Notifications", [oLocalChanges]);
    		}
    		// this._addNotificationToSO(oViewModel, oNotification, oLocalChanges);
    		// this._updateExtractedNotifications(oViewModel, oNotification, oLocalChanges);
    		
    		return this.saveUserSettings(oViewModel.getProperty("/UserSettings"));
    	},
    	
    	_updateExtractedNotifications: function(oViewModel, oNotification, oLocalChanges) {
    	
    	var aNotAddedNotifications = oViewModel.getProperty("/Data/Notifications/notAdded");
    		// oLocalChanges = this._parseNotification(oNotification, oLocalChanges);
    		if (aNotAddedNotifications) {
    			var iIndex = _.findIndex(aNotAddedNotifications, {NotificationId: oLocalChanges.NotificationId});
    			if (iIndex >= 0) {
    				aNotAddedNotifications.splice(iIndex, 1);
    			} 
    			
    			oViewModel.setProperty("/Data/Notifications/notAdded", aNotAddedNotifications);
    		} else {
    			oViewModel.setProperty("/Data/Notifications/notAdded", [oLocalChanges]);
    		}
    	},
    	
    	_mapNotification: function(oLocalSOChanges, oNotification, oLocalNotifChanges) {
    		//TODO fix this logic, workaround for demo only
    		
			if (!oLocalSOChanges.OrderId) {
				oLocalSOChanges.OrderId = oNotification.NotificationId ? oNotification.NotificationId : oNotification.key;
			}
			if (!oLocalSOChanges.OperationId) {
				oLocalSOChanges.OperationId = "0000";
			}
			if (!oLocalSOChanges.OperationText) {
    			oLocalSOChanges.OperationText = oNotification.DamageText ? oNotification.DamageText : oNotification.description;
			}
			if (!oLocalSOChanges.OrderType) {
    		oLocalSOChanges.OrderType = oNotification.NotificationType ? oNotification.NotificationType: oNotification.type;
			}
    		//TODO replace with todays date
    		// var dDate = moment.utc("20191108", "YYYYMMDD").startOf("day").toDate(); // TODO: Use todays date (above)
    		oLocalSOChanges.EarliestStartDate = oLocalNotifChanges.EarliestStartDate ? new Date(oLocalNotifChanges.EarliestStartDate) : new Date(oNotification.NotificationDate);
    		
    		if (!oLocalSOChanges.FuncLocId) {
    			oLocalSOChanges.FuncLocId = oNotification.FuncLocId ? oNotification.FuncLocId : oLocalSOChanges.FuncLocId;
    		}
    		if (!oLocalSOChanges.FuncLocDesc) {
    		oLocalSOChanges.FuncLocDesc = oNotification.FuncLocDesc ? oNotification.FuncLocDesc : oLocalSOChanges.FuncLocDesc;
    		}
    		if (!oLocalSOChanges.UserStatus) {
    		oLocalSOChanges.UserStatus = oNotification.UserStatus ? oNotification.UserStatus : oLocalSOChanges.UserStatus;
    		}
    		if (!oLocalSOChanges.EquipmentId) {
    		oLocalSOChanges.EquipmentId = oNotification.EquipmentId;
    		}
    		
    		if (!oLocalSOChanges.CustomerId) {
    		oLocalSOChanges.CustomerId = oNotification.CustomerId;
    		oLocalSOChanges.CustomerText = oNotification.CustomerText;
    		}
    		
    		oLocalSOChanges.Comments = oNotification.Comments;
    		
    		oLocalSOChanges.Duration = "7.0";
    		oLocalSOChanges.IsNotification = true;
    		
    		oLocalSOChanges.BundledSO = oLocalNotifChanges.BundledSO;
			return oLocalSOChanges;
		},
    	
    	removeLocalChangesForServiceOperation: function(oViewModel, sServiceOrderNumber, sOperation, oLocalChanges) {
    		var aServiceOrders = oViewModel.getProperty("/UserSettings/LocalChanges/ServiceOperations");
    		if (aServiceOrders) {
    			var iIndex = _.findIndex(aServiceOrders, {OrderId: sServiceOrderNumber, OperationId: sOperation});
    			if (iIndex >= 0) {
    				aServiceOrders.splice(iIndex, 1);
    			} 
    			oViewModel.setProperty("/UserSettings/LocalChanges/ServiceOperations", aServiceOrders);
    		}
    		
    		return this.saveUserSettings(oViewModel.getProperty("/UserSettings"));
    	},
    	
		removeLocalChangesForNotification: function(oViewModel, sNotification, oLocalChanges) {
			var aNotifications = oViewModel.getProperty("/UserSettings/LocalChanges/Notifications");
			if (aNotifications) {
				var iIndex = _.findIndex(aNotifications, {NotificationId: sNotification});
				if (iIndex >= 0) {
					aNotifications.splice(iIndex, 1);
				} 
				oViewModel.setProperty("/UserSettings/LocalChanges/Notifications", aNotifications);
			}
			
			return this.saveUserSettings(oViewModel.getProperty("/UserSettings"));
    	},
    	
    	getLocalChangesUnplannedTasks: function(oViewModel) {
    		var aUnplanned = oViewModel.getProperty("/UserSettings/LocalChanges/UnplannedTasks");
    		if (!aUnplanned) {
    			return [];
    		}
    		return aUnplanned;
    	},
    	
    	getLocalChangesUnplannedTasksForDate: function(oViewModel, dDate) {
    		var aUnplanned = oViewModel.getProperty("/UserSettings/LocalChanges/UnplannedTasks");
    		if (!aUnplanned) {
    			return [];
    		}
    		return _.filter(aUnplanned, function(oUnplanned) { 
    			return moment(oUnplanned.EarliestStartDate).isSame(moment(dDate), "day");
    		});
    	},
   	
    	saveLocalChangesUnplannedTasks: function(oViewModel, aUnplanned) {
    		oViewModel.setProperty("/UserSettings/LocalChanges/UnplannedTasks", aUnplanned);
    		return this.saveUserSettings(oViewModel.getProperty("/UserSettings"));
    	},
    	
    	_initializePersonalizationContainer: function (oView) {
    		if (this.oContainer) {
    			return new Promise(function (fResolve, fReject) { fResolve(); });
    		}
			return new Promise(function (fResolve, fReject) {
				var oComponent = sap.ui.core.Component.getOwnerComponentFor(oView);
				var oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oScope = {
					keyCategory: oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: oPersonalizationService.constants.writeFrequency.HIGH,
					clientStorageAllowed: false,
					validity: "infinity"
				};

				oPersonalizationService.getContainer("com.vestas.vestas-planoftheday", oScope, oComponent)
					.fail(function () {
						jQuery.sap.log.error("Loading personalization data failed.");
						MessageBox.show(
							"Loading session data failed.", {
								icon: MessageBox.Icon.ERROR,
								title: "Error",
								actions: [MessageBox.Action.OK]
							});
						fReject(false);
					})
					.done(function (oContainer) {
						this.oContainer = oContainer;
						fResolve();
					}.bind(this));
			}.bind(this));
		}
    };
});
