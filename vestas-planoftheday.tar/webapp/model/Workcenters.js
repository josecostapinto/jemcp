/*global moment, _ */
sap.ui.define([
	"../libs/lodash.min"
], function(NameToAvoidNamingConflictsLodash) {
    "use strict";

    return {
    	padWithGroups: function(aWorkcenters) {
    		var aWithGroups = _.map(aWorkcenters, function(oWorkcenter) { 
				return {
					group: "Workcenters from settings",
					key: oWorkcenter.WorkcenterId,
					name: oWorkcenter.WorkcenterText
				};
			});
			aWithGroups.push({name: "", group: "Custom workcenters", key: "custom"});
			return aWithGroups;
    	}
    };
});
