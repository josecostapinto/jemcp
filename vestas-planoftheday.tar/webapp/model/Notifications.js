  /*global moment, _ */
sap.ui.define([
	"../libs/lodash.min"
], function(NameToAvoidNamingConflictsLodash) {
    "use strict";

    return {
     	extractNotAdded: function(aNotifications, aLocalChanges) {
     		
			if (aLocalChanges) {
				_.forEach(aLocalChanges, function(oLocalChanges) {
					var iIndex = _.findIndex(aNotifications, {NotificationId: oLocalChanges.NotificationId});
	    			if (iIndex >= 0) {
	    				aNotifications.splice(iIndex, 1);
	    			}
				});
			}	

			// Add "hours ago" field to popup list
			var id = "hoursAgo";
			for (var i=0; i<aNotifications.length; i++) {

				// console.log("aNotifications[i] Date: ", aNotifications[i].NotificationDate);
				// console.log("aNotifications[i] Time: ", aNotifications[i].NotificationTime);
				// console.log("aNotifications[i] Timezone: ", aNotifications[i].Timezone);
				// console.log("  aNotifications[i] Date UTC: ", aNotifications[i].NotificationDateUtc);
				// console.log("  aNotifications[i] Time UTC: ", aNotifications[i].NotificationTimeUtc);

				// Subtract current date+time with notification date+time, with timezone adjustment

				var CurrentDateTZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var CurrentDateTZOffsetMinutes = new Date(0).getTimezoneOffset();
				// console.log("CurrentDateTZOffsetMs: ", CurrentDateTZOffsetMs);
				// console.log("CurrentDateTZOffsetMinutes: ", CurrentDateTZOffsetMinutes);

				var notifTime = moment.duration(aNotifications[i].NotificationTimeUtc);
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy-MM-dd"});

				var curr_timestamp = new Date().getTime() + CurrentDateTZOffsetMs;
				var currentDateUTC = new Date(curr_timestamp);

				var dateCurrentFormatted = oDateFormat.format(currentDateUTC);
				var dateNotifFormatted = oDateFormat.format(aNotifications[i].NotificationDateUtc);

				var dateTimeNotf = dateNotifFormatted + " " + notifTime.hours() + ":" + notifTime.minutes() + ":00";
				var dateTimeCurrent = dateCurrentFormatted + " " + currentDateUTC.getHours() + ":" + currentDateUTC.getMinutes() + ":00";

				var diffNotif = moment(dateTimeCurrent).diff(moment(dateTimeNotf));
				var durationNotif = moment.duration(diffNotif);
				var diffNotifHours = durationNotif.asHours();
				
				// console.log("dateTimeNotifUTC: ", dateTimeNotf);
				// console.log("dateTimeCurrentUTC: ", dateTimeCurrent);
				// console.log("diff notif dates hours: ", diffNotifHours);

				aNotifications[i][id] = Math.round(diffNotifHours);
				
			}

			return aNotifications;
     	}
    	
    };
});
   	
    	