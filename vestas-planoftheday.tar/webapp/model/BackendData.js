/*global moment, _ */
sap.ui.define([
	"../libs/lodash.min",
], function(NameToAvoidNamingConflictsLodash) {
    "use strict";

    return {
    	getServiceOperationsForDay: function(oBackendModel, aSites, dDay) {
    		return new Promise(function(fResolve, fReject) {
    			var oFuncLocFilter = this._sitesToFilter(aSites);
				var oStartDateFilter = new sap.ui.model.Filter({
					path: "EarliestStartDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: dDay
				});
				var oReleasedFilter = new sap.ui.model.Filter({
					path: "OrderReleased",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "X"
				});
	    		oBackendModel.read("/ServiceOrderOperationSet", {
	    			filters: [oFuncLocFilter, oStartDateFilter, oReleasedFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 1
	    		});
    		}.bind(this));
    	},
    	
    	getServiceOperationsForDateRange: function(oBackendModel, aSites, dStartDate, dEndDate) {
    		return new Promise(function(fResolve, fReject) {
    			
				var oFuncLocFilter = this._sitesToFilter(aSites);
    			var oStartDateFilter = new sap.ui.model.Filter({
				    filters: [
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.GE,
				        value1: dStartDate
				      }),
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.LE,
				        value1: dEndDate
				      }),
				    ],
				    and: true
				  });
				var oReleasedFilter = new sap.ui.model.Filter({
					path: "OrderReleased",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "X"
				});
				oBackendModel.read("/ServiceOrderOperationSet", {
	    			filters: [oFuncLocFilter, oStartDateFilter, oReleasedFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 1
    			});
	    		
    		}.bind(this));
    	},
    	
    	getServiceOperationsPerWorkcenterForDateRange: function(oBackendModel, aWorkcenters, dStartDate, dEndDate) {
    		return new Promise(function(fResolve, fReject) {
    			
    			var oWorkcenterFilter = this._workcentersToFilter(aWorkcenters);
    			var oStartDateFilter = new sap.ui.model.Filter({
				    filters: [
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.GE,
				        value1: dStartDate
				      }),
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.LE,
				        value1: dEndDate
				      }),
				    ],
				    and: true
				  });
				var oReleasedFilter = new sap.ui.model.Filter({
					path: "OrderReleased",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "X"
				});
	    		oBackendModel.read("/ServiceOrderOperationSet", {
	    			filters: [oWorkcenterFilter, oStartDateFilter, oReleasedFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 6
	    		});
    		}.bind(this));
    	},
    	
    	getServiceOperationsForEquipment: function(oBackendModel, sEquipment) {
    		return new Promise(function(fResolve, fReject) {
    			
    			var oEquipmentFilter = new sap.ui.model.Filter({
					path: "EquipmentId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sEquipment
				});
				
				var oOrderTypeFilter = new sap.ui.model.Filter({
				    filters: [
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM01'
				      }),
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM02'
				      }),
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM04'
				      }),
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM05'
				      }),
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM06'
				      }),
				      new sap.ui.model.Filter({
				        path: 'OrderType',
				        operator: sap.ui.model.FilterOperator.EQ,
				        value1: 'YM07'
				      }),
				    ]
				  });
				
	    		oBackendModel.read("/ServiceOrderOperationSet", {
	    			filters: [oEquipmentFilter, oOrderTypeFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 1
	    		});
    		});
    	},
    	
    	getIncompletedTasks: function(oBackendModel, aSites, dDay) {
    		return new Promise(function(fResolve, fReject) {
    			
    			var oFuncLocFilter = this._sitesToFilter(aSites);
    			var dStartDate = new Date(dDay);
				dStartDate.setDate(dStartDate.getDate() - 4 * 7);

				var oStartDateFilter = new sap.ui.model.Filter({
				    filters: [
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.GE,
				        value1: dStartDate
				      }),
				      new sap.ui.model.Filter({
				        path: 'EarliestStartDate',
				        operator: sap.ui.model.FilterOperator.LE,
				        value1: dDay
				      }),
				    ],
				    and: true
				  });

	    		oBackendModel.read("/ServiceOrderOperationSet", {
	    			filters: [oFuncLocFilter, oStartDateFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 3
	    		});
    		}.bind(this));
    	},
    	
    	getNotifications: function(oBackendModel, aSites) {
    		return new Promise(function(fResolve, fReject) {

    			var oFuncLocFilter = this._sitesToFilter(aSites);

	    		oBackendModel.read("/ServiceNotificationSet", {
	    			filters: [oFuncLocFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 5
	    		});
    		}.bind(this));
    	},
    	
    	lookupSiteId: function(oBackendModel, sSiteId) {
    		return new Promise(function(fResolve, fReject) {
	    		var oFilter = new sap.ui.model.Filter({
					path: "FuncLocId",
					operator: sap.ui.model.FilterOperator.StartsWith,
					value1: sSiteId
				});
	    		oBackendModel.read("/FunctionalLocationSet", {
	    			filters: [oFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 4
	    		});
    		});
    	},
    	lookupWorkcenterId: function(oBackendModel, sWorkcenterId) {
    		return new Promise(function(fResolve, fReject) {
	    		var oFilter = new sap.ui.model.Filter({
					path: "WorkcenterId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sWorkcenterId
				});
	    		oBackendModel.read("/WorkcenterSet", {
	    			filters: [oFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 4
	    		});
    		});
    	},
    	lookupServiceTeam: function(oBackendModel, sWorkcenterId, dDate) {
    		return new Promise(function(fResolve, fReject) {
	    		var oWorkcenterIdFilter = new sap.ui.model.Filter({
					path: "WorkcenterId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sWorkcenterId
				});
				var oDateFilter = new sap.ui.model.Filter({
					path: "Date",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: dDate
				});
	    		oBackendModel.read("/ServiceTeamSet", {
	    			filters: [oWorkcenterIdFilter, oDateFilter],
	    			success: fResolve,
	    			error: fReject,
	    			batchGroupId: 4
	    		});
    		});
    	},
    	_sitesToFilter: function(aSites) {
    		return new sap.ui.model.Filter({
    			filters: _.map(aSites, function(sSite) {
    				return new sap.ui.model.Filter({
						path: "FuncLocId",
						operator: sap.ui.model.FilterOperator.StartsWith,
						value1: sSite
					});
    			}),
    			and: false
    		});
    	},
    	
    	_workcentersToFilter: function(aWorkcenters) {
    		return new sap.ui.model.Filter({
    			filters: _.map(aWorkcenters, function(oWorkcenter) {
    				return new sap.ui.model.Filter({
						path: "WorkcenterId",
						operator: sap.ui.model.FilterOperator.StartsWith,
						value1: oWorkcenter.WorkcenterId
					});
    			}),
    			and: false
    		});
    	},
    }; 
});
