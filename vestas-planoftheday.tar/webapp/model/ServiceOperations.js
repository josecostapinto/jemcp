  /*global moment, _ */
  sap.ui.define([
  	"../libs/lodash.min",
  	"./DataHandler"
  ], function (NameToAvoidNamingConflictsLodash, DataHandler) {
  	"use strict";

  	return {
  		mergeWithLocalChanges: function (aServiceOrderOperations, aLocalChanges, aWorkcenters) {
  			if (aServiceOrderOperations) {
  				aServiceOrderOperations = this._addNotificationState(aServiceOrderOperations);
  			}
  			if (aLocalChanges) {
  				var aMerged = _.map(aServiceOrderOperations, function (oServiceOrder) {
  					var oChanges = _.find(aLocalChanges, {
  						OrderId: oServiceOrder.OrderId,
  						OperationId: oServiceOrder.OperationId
  					});
  					var oClone = _.cloneDeep(oServiceOrder);
  					return this._mergeItem(oServiceOrder, oClone, oChanges);
  				}.bind(this));
  				aMerged = this._mergeNotification(aMerged, aLocalChanges, aWorkcenters);
  				return aMerged;
  			}
  			return aServiceOrderOperations;
  		},
  		_mergeItem: function (oOriginal, oItem, oChanges) {
  			if (oChanges) {
  				var hasChanges = false;
  				if (oChanges.WorkcenterId) {
  					oItem.OriginalWorkcenterId = oOriginal.WorkcenterId;
  					oItem.OriginalWorkcenterText = oOriginal.WorkcenterText;
  					oItem.WorkcenterId = oChanges.WorkcenterId;
  					hasChanges = true;
  					oItem.WorkcenterText = oChanges.WorkcenterText;
  				}
  				if (oChanges.EarliestStartDate) {
  					oItem.OriginalEarliestStartDate = oOriginal.EarliestStartDate;
  					oItem.EarliestStartDate = new Date(oChanges.EarliestStartDate);
  					oItem.MoveReason = oChanges.MoveReason;
  					hasChanges = true;
  				}
  				if (oChanges.Removed) {
  					oItem.OriginalEarliestStartDate = oOriginal.EarliestStartDate;
  					delete oItem.EarliestStartDate;
  					oItem.MoveReason = oChanges.MoveReason;
  					hasChanges = true;
  				}
  				if (oChanges.Team || oChanges.Team === "") {
  					oItem.OriginalTeam = oOriginal.Team;
  					oItem.Team = oChanges.Team;
  					hasChanges = true;
  				}
  				if (oChanges.Comments) {
  					oItem.Comments = oChanges.Comments;
  					hasChanges = true;
  				}
  				oItem.HasChanges = hasChanges;
  			}
  			// oItem.IsNotification = false;
  			return oItem;
  		},

  		_mergeNotification: function (aMerged, aLocalChanges, aWorkcenters) {
  			var aMergedWithNotif = _.map(aLocalChanges, function (oLocalChange) {
  				if (oLocalChange.IsNotification) {
  					oLocalChange.EarliestStartDate = new Date(oLocalChange.EarliestStartDate);
  					if (oLocalChange.WorkcenterId) {
  						var oWC =  _.find(aWorkcenters, function(oWorkcenter) {
		    				return oWorkcenter.key === oLocalChange.WorkcenterId;
		    			});
		    			if (oWC.name) {
  							oLocalChange.WorkcenterText = oWC.name;
		    			}
  					}
  					aMerged.push(oLocalChange);
  				}
  			});
  			return aMerged;
  		},

  		perDay: function (aServiceOperations, dDate, fHoursPerDay) {
  			var aSO = [];
  			var iTeamLength = 0;
  			var aMap = this._getDayMap(fHoursPerDay);
  			
  			aServiceOperations && aServiceOperations.forEach(function(oServiceOperation) {
  				if (oServiceOperation.TeamArray) {
  				oServiceOperation.TeamArray.length > 0 ? iTeamLength = oServiceOperation.TeamArray.length : iTeamLength = 1;
	  			} else {
	  				iTeamLength = 1
	  			}
	  			// if (oServiceOperation.TeamArray && oServiceOperation.TeamArray.length > 5) {
	  			// 	oServiceOperation.TeamArray = [];	
	  			// 	oServiceOperation.Team = "";
	  			// }
  				if (oServiceOperation.EarliestStartDate.toDateString() === dDate.toDateString()) {
  					aSO.push(oServiceOperation);
  				} else {
  					if ((parseInt(oServiceOperation.Duration) / iTeamLength) > fHoursPerDay ) {
  						var diff = oServiceOperation.EarliestStartDate - dDate;
  						var iDayDiff = diff / (1000 * 3600 * 24);
  						 if (parseInt(aMap[parseInt(iDayDiff)]) <= parseInt(oServiceOperation.Duration)) {
  						 	aSO.push(oServiceOperation);
  						 	oServiceOperation.Started = true;
  						 }
  					} 
  				}
  			});
  			return aSO;
  			// return _.filter(aServiceOperations, {
  			// 	EarliestStartDate: dDate
  			// });
  		},
  		
  		_getDayMap: function(fHoursPerDay) {
  			return {
  				"-1": fHoursPerDay.toString(),
  				"-2": (fHoursPerDay*2).toString(),
  				"-3": (fHoursPerDay*3).toString(),
  				"-4": (fHoursPerDay*4).toString(),
  				"-5": (fHoursPerDay*5).toString(),
  				"-6": (fHoursPerDay*6).toString(),
  				"-7": (fHoursPerDay*7).toString()
  			}
  		},
  		
  		movedFromDay: function (aServiceOperations, dDate) {
  			return _.filter(aServiceOperations, {
  				OriginalEarliestStartDate: dDate
  			});
  		},
  		perTurbine: function (aServiceOperations, fHoursPerDay) {
  			var aGrouped = _.groupBy(aServiceOperations, "FuncLocId");
  			return _.map(_.keys(aGrouped), function (sKey) {
  				var oFirst = aGrouped[sKey][0];
  				var oTurbine = {
  					key: oFirst.FuncLocId,
  					asset: oFirst.FuncLocDesc,
  					serviceOrders: _.flatMap(aGrouped[sKey], function(oItem) { return this._soToAppointment(oItem, fHoursPerDay); }.bind(this))
  				};
  				return oTurbine;
  			}.bind(this));
  		},
  		perWorkcenter: function (aServiceOperations, fHoursPerDay) {
  			var aGrouped = _.groupBy(aServiceOperations, "WorkcenterId");
  			return _.map(_.keys(aGrouped), function (sKey) {
  				var oFirst = aGrouped[sKey][0];
  				var oTurbine = {
  					key: oFirst.WorkcenterId,
  					asset: oFirst.WorkcenterText,
  					serviceOrders: _.flatMap(aGrouped[sKey], function(oItem) { return this._soToAppointment(oItem, fHoursPerDay); }.bind(this))
  				};
  				return oTurbine;
  			}.bind(this));
  		},
  		getCustomers: function (aServiceOperations) {
  			var aCustomers = [];
  			aServiceOperations.filter((obj, pos, arr) => {
  				if (arr.map(mapObj => mapObj["CustomerId"]).indexOf(obj["CustomerId"]) === pos) {
  					var oCustomer = {};
  					oCustomer.key = obj.CustomerId;
  					oCustomer.value = obj.CustomerText;
  					aCustomers.push(oCustomer);
  				}
  			});
  			return aCustomers;
  		},
  		_addNotificationState: function (aServiceOrderOperations) {
  			aServiceOrderOperations.forEach(function (oServiceOrder) {
  				oServiceOrder.IsNotification = false;
  			});
  			return aServiceOrderOperations;
  		},
  		_setEndFromDuration: function(dStartDate, oItem, sDuration, fHoursPerDay) {
  			var iTeamLength = 0;
  			var aTeam = []; 
  			if (oItem.team) {
  				aTeam = oItem.team.split(',');
  				aTeam.length > 0 ? iTeamLength = aTeam.length : iTeamLength = 1;
	  			} else {
	  				iTeamLength = 1
	  			}
  			if (dStartDate) {
	  			var iDays = Math.ceil((parseFloat(sDuration) / iTeamLength) / parseFloat(fHoursPerDay));
	  			oItem.end = moment(dStartDate).add(iDays, "day").toDate();
  			}
  		},
  		_soToAppointment: function (oSO, fHoursPerDay) {
  			var oServiceOperation = {};
  			oServiceOperation.key = oSO.OrderId;
  			oServiceOperation.start = oSO.EarliestStartDate;
  			oServiceOperation.description = oSO.OperationText;
  			oServiceOperation.serviceOrderNumber = oSO.OrderId;
  			oServiceOperation.operation = oSO.OperationId;
  			oServiceOperation.workcenter = oSO.WorkcenterText;
  			oServiceOperation.turbineAsset = oSO.FuncLocDesc;
  			oServiceOperation.duration = oSO.Duration;
  			oServiceOperation.customer = oSO.CustomerText;
  			oServiceOperation.team = oSO.Team;
  			this._setEndFromDuration(oSO.EarliestStartDate, oServiceOperation, oSO.Duration, fHoursPerDay);
  			oServiceOperation.orderNumber = oSO.OrderId + "/" + oSO.OperationId;
  			oServiceOperation.serviceOrderType = oSO.OrderType;
  			oServiceOperation.comments = oSO.Comments;
  			oServiceOperation.type = "Type16";
  			oServiceOperation.tentative = false;
  			//TODO oServiceOperation.team
  			oServiceOperation.status = oSO.UserStatusText;

  			if (oSO.MoveReason) {
  				oServiceOperation.moveReason = oSO.MoveReason;
  			}

  			if (oSO.IsNotification) {
  				oServiceOperation.type = "Type02";
  				oServiceOperation.bundledSO = oSO.BundledSO;
  				// oServiceOperation.tentative = true;
  			}

  			// If the original start date has been changed also return a cloned appointment
  			if (oSO.OriginalEarliestStartDate && oSO.EarliestStartDate) {
  				var oClone = _.cloneDeep(oServiceOperation);
  				oClone.start = oSO.OriginalEarliestStartDate;
  				oClone.workcenter = oSO.OriginalWorkcenterText ? oSO.OriginalWorkcenterText : oSO.WorkcenterText;
  				this._setEndFromDuration(oSO.OriginalEarliestStartDate, oClone, oSO.Duration, fHoursPerDay);
  				oClone.tentative = true;
  				oClone.type = "Type16";
  				oServiceOperation.type = "Type07";
  				return [oServiceOperation, oClone];
  			} else if (oSO.OriginalWorkcenterText) {
  				var oCloneWc = _.cloneDeep(oServiceOperation);
  				oCloneWc.start = oSO.OriginalEarliestStartDate ? oSO.OriginalEarliestStartDate : oSO.EarliestStartDate;
  				oCloneWc.workcenter = oSO.OriginalWorkcenterText;
  				this._setEndFromDuration(oCloneWc.start, oCloneWc, oSO.Duration, fHoursPerDay);
  				oCloneWc.tentative = true;
  				oCloneWc.type = "Type16";
  				oServiceOperation.type = "Type07";
  				return [oServiceOperation, oCloneWc];
  			} else if (!oSO.EarliestStartDate) {
  				// If startdate is not set, the operation has been removed from the plan. Return nothing.
  				return [];
  			} else {
  				return [oServiceOperation];
  			}

  		},
  		splitTeamArray: function (aSOs) {
  			_.forEach(aSOs, function (oOperation) {
  				if (oOperation.Team) {
  					oOperation.TeamArray = _.map(oOperation.Team.split(","), function (sTeamMember) {
  						return {
  							Initials: sTeamMember.trim()
  						}
  					});
  				} else {
  					oOperation.TeamArray = [];
  				}
  			});
  		},
  		
  		setOriginalWorkcenter: function (aMerged, aMappedPerWorkcenter) {
  			var aSwap = [];
  			var fCheckWs = function (oSO) {
  				aMappedPerWorkcenter.forEach(function (oMapped) {
  						var iIndex = _.findIndex(oMapped.serviceOrders, {
  						key: oSO.OrderId,
  						operation: oSO.OperationId,
  						tentative: true
  					});
  					if (iIndex >= 0) {
  						aSwap.push(oMapped.serviceOrders[iIndex]);
  						oMapped.serviceOrders.splice(iIndex, 1);
  					}
  				})
  			};
  			
  			aMerged && aMerged.forEach(function (oSO) {
  				if (oSO.OriginalWorkcenterId) {
  					fCheckWs(oSO);
  				}
  			});
  			
  			aSwap.forEach(function (oSwap) {
  				var iIndex = _.findIndex(aMappedPerWorkcenter, {
  					asset: oSwap.workcenter
  				});
  				if (iIndex >= 0) {
  					aMappedPerWorkcenter[iIndex].serviceOrders.push(oSwap);
  				} else {
  				    var oNewKey = { key : '', asset: oSwap.workcenter, serviceOrders: [oSwap]};
  				    aMappedPerWorkcenter.push(oNewKey);
  				}
  			});
  			
  			return aMappedPerWorkcenter;
  		}
  	};
  });