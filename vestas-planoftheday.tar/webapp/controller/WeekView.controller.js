sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../model/DataHandler",
	"../utils/toolbarHandler"
], function (BaseController, MessageBox, Utilities, History, JSONModel, MessageToast, Fragment, DataHandler, ToolbarHandler) {
	"use strict";

	return BaseController.extend("plancalendar.controller.WeekView", {
		_updatedTurbineData: null,
		_updatedWcData: null,
		oResourceModel: null,
		
		handleRouteMatched: function (oEvent) {

			var oViewModel = this.getView().getModel("viewModel");
			var bIsInitialized = oViewModel.getProperty("/IsDataInitialized");
			var oComponent = this.getOwnerComponent();
			this.oResourceModel = oComponent.getModel("i18n").getResourceBundle();
			
			if (!bIsInitialized) {
				DataHandler.initializeData(this.getView()).then(function (bResult) {
					if (!bResult) {
						this.oRouter.navTo("Settings");
					}
				}.bind(this));
			}

			// set monday as first day of the current week
			var oMonday = this._getMonday(new Date());
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/StartOfWeek", oMonday);
			var sSelectedTab = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab");
			if (!sSelectedTab) {
				oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab", "turbineKey");
			}
			this._setCustomerSelectDrop(oViewModel);
			oViewModel.setProperty("/ApplicationBusy", false);
		},
		
		_setCustomerSelectDrop: function (oViewModel) {
			var aSOCustomers = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/customers");
			var aCustomers = [{
				key: "all",
				value: "All"
			}];

			aCustomers = aCustomers.concat(aSOCustomers);
			var oCustomerModel = new JSONModel();
			oCustomerModel.setData(aCustomers);
			this.getView().byId("searchCustomerText").setModel(oCustomerModel);
		},

		_getMonday: function (oDate) {
			var sDay = oDate.getDay(),
				iDiff = oDate.getDate() - sDay + (sDay == 0 ? -6 : 1);
			return new Date(oDate.setDate(iDiff));
		},

		handleIconTabBarSelect: function (oEvent) {
			var oViewModel = oEvent.getSource().getModel("viewModel");
			var oBackendModel = oEvent.getSource().getModel("backend");
			var oUserSettings = oViewModel.getProperty("/UserSettings");
			var oCalendar = this.getView().byId("PC1");
			var oRow = this.getView().byId("PC2");
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab", oEvent.getParameter("key"));
			if (oEvent.getParameter("key") === "turbineKey") {
				oRow.setIcon("sap-icon://customfont/icon-turbine-vestas");
				oCalendar.bindAggregation("rows", "viewModel>/Data/ServiceOperationsFromDateRange/perTurbine", oRow);
			} else if (oEvent.getParameter("key") === "workcenterKey") {
				oRow.setIcon("sap-icon://shipping-status");
				oCalendar.bindAggregation("rows", "viewModel>/Data/ServiceOperationsFromDateRange/perWorkcenter", oRow);
			}
		},
		
		setPlaceholderForTab: function(sTab) {
			var sPlaceholder = ' ';
			if (sTab) { 
				sTab === 'turbineKey' ? sPlaceholder = this.oResourceModel.getText("searchByTurbineTxt") : sPlaceholder = this.oResourceModel.getText("searchByWorkcenterTxt")
			}
			return sPlaceholder;
		},
		
		_onSettingsPress: function(oEvent) {
			return new Promise(function(fnResolve) {

				this.oRouter.navTo("ViewSettings");
			}.bind(this)).catch(function(err) {
				if (err !== undefined) {
					MessageBox.error(err.message);
				}
			});
		},
		
		_onReloadSapDataPress: function(oEvent) {
			DataHandler.initializeData(this.getView());			
		},	
		
		canModifyAppointments: function (sRole) {
			return true;
		},

		handleAppointmentDragEnter: function (oEvent) {
			if (this.isAppointmentOverlap(oEvent, oEvent.getParameter("calendarRow"))) {
				oEvent.preventDefault();
			}
		},

		handleAppointmentDrop: function (oEvent) {
			var oViewModel = oEvent.getSource().getBindingContext("viewModel").getModel();
			var oServiceOrder = oEvent.getParameter("appointment").getBindingContext("viewModel").getObject();
			var oAppointment = oEvent.getParameter("appointment"),
				oStartDate = oEvent.getParameter("startDate"),
				oCalendarRow = oEvent.getParameter("calendarRow");
				
			var sSelectedTab = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab");
			
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oServiceOrder.serviceOrderNumber);
			var oLocalSOChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation);
				
			if ((oAppointment.getParent() !== oCalendarRow) && sSelectedTab === 'turbineKey'){
				MessageToast.show(this.oResourceModel.getText("operationNotAllowedMsg"));
				return;
			} else if ((oAppointment.getParent() !== oCalendarRow) && sSelectedTab === 'workcenterKey'){
				oLocalSOChanges.WorkcenterId = oCalendarRow.getKey();
				oLocalSOChanges.WorkcenterText = oCalendarRow.getTitle();
			}
			
			oLocalSOChanges.EarliestStartDate = new Date(oStartDate);
			
			if (oLocalSOChanges.IsNotification) {
				oLocalNotifChanges.EarliestStartDate = new Date(oStartDate);
				DataHandler
				.saveLocalChangesForNotification(oViewModel, oServiceOrder, oLocalNotifChanges)
				.then(function() {
					DataHandler._mapNotification(oLocalSOChanges,oServiceOrder,oLocalNotifChanges);
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, "0000", oLocalSOChanges);
					DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
					this.getView().byId("PC1").setStartDate(this._getMonday(oStartDate));
				}.bind(this));
			} else {
				this._setMoveReason(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation, oLocalSOChanges, oStartDate);
			}
		},
		
		_setMoveReason: function(oViewModel, sServiceOrderNumber, sOperation, oLocalSOChanges, oStartDate) {
			var that = this;
			
			var oDialog = new sap.m.Dialog({
				title: that.oResourceModel.getText("dateMovedTxt"),
				type: 'Message',
				content: [
					new sap.m.TextArea('reasonText', {
						width: '100%',
						placeholder: that.oResourceModel.getText("addReasonTxt")
					})
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: that.oResourceModel.getText("confirmTxt"),
					press: function (oEvent) {
						oLocalSOChanges.MoveReason = this.getParent().getContent()[0].getValue();
						DataHandler
						.saveLocalChangesForServiceOperation(oViewModel, sServiceOrderNumber, sOperation, oLocalSOChanges)
						.then(function() {
							DataHandler.reloadWeeklyServiceOperations(that.getView().getModel("viewModel"), that.getView().getModel("backend"));
							that.getView().byId("PC1").setStartDate(that._getMonday(oStartDate));
							oDialog.close();
						}.bind(that));
					}
				}),
				endButton: new sap.m.Button({
					text: that.oResourceModel.getText("cancelTxt"),
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},
		
		handleDatePickerChange: function(oEvent) {
			// sap.ui.getCore().byId("inputReason").setVisible(true);
			var oPopupModel = oEvent.getSource().getModel("popupModel");
			oPopupModel.setProperty("/saveEnabled", true);
		},
		
		handleAppointmentSelect: function (oEvent) {
			var oAppointment = oEvent.getParameter("appointment");

			if (oAppointment) {
				this._handleSingleAppointment(oAppointment);
			}
		},

		_handleSingleAppointment: function (oAppointment) {
			this.onOpenDialog(oAppointment);
		},

		isAppointmentOverlap: function (oEvent, oCalendarRow) {
			var oAppointment = oEvent.getParameter("appointment"),
				oStartDate = oEvent.getParameter("startDate"),
				oEndDate = oEvent.getParameter("endDate"),
				bAppointmentOverlapped;

			return bAppointmentOverlapped;
		},

		_onButtonPress: function (oEvent) {
			this.getView().getModel("viewModel").setProperty("/ApplicationBusy", true);
			setTimeout(function() {
				this.oRouter.navTo("DayView");
			}.bind(this), 100);
		},

		formatDateTimeUTCtoLocale: function (utcDate) {
			return utcDate ? new Date(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate(), utcDate.getUTCHours(), utcDate.getUTCMinutes(),
				utcDate.getUTCSeconds()) : null;

		},

		formatDateTimeUTCtoLocaleForStartDate: function (utcDate) {
			return utcDate ? new Date(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate(), utcDate.getUTCHours(), utcDate.getUTCMinutes(),
				utcDate.getUTCSeconds()) : new Date(864000000000000);

		},

		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("WeekView").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			sap.ui.core.IconPool.addIcon('icon-turbine-vestas', 'customfont', 'icomoon', 'e900');
		},

		onOpenDialog: function (oAppointment) {
			var oViewModel = oAppointment.getBindingContext("viewModel");
			var oTask = oViewModel.getObject();
			var oReasonField = sap.ui.getCore().byId("inputReason");
			
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			
			this._oDialog = sap.ui.xmlfragment("plancalendar.view.Notification", this);
			this.getView().addDependent(this._oDialog);
			this._initializeFields();
			this._oDialog.setModel(this.getView().getModel("viewModel"));
			this._initializeFields();
			sap.ui.getCore().byId("DTPStartDate").setDateValue(oTask.start);
			this._oDialog.setBindingContext(oViewModel);
			this._oDialog.openBy(oAppointment);
		},

		
		handleSave: function (oEvent) {

			var oNewDate = sap.ui.getCore().byId("DTPStartDate").getDateValue();
			var oReasonField = sap.ui.getCore().byId("inputReason");
			var sReasonMoved = oReasonField.getValue();
			var oViewModel = oEvent.getSource().getBindingContext().getModel();
			var oServiceOrder = oEvent.getSource().getBindingContext().getObject();
			var oOldStartDate = oServiceOrder.start;
			
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oServiceOrder.serviceOrderNumber);
			var oLocalSOChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation);
			
			if (oNewDate.toDateString() !== oOldStartDate.toDateString()) {
					oLocalSOChanges.EarliestStartDate = new Date(oNewDate);
					oLocalSOChanges.MoveReason = sReasonMoved;
			}
			
			if (oLocalSOChanges.IsNotification) {
				if (oNewDate.toDateString() !== oOldStartDate.toDateString()) {
					oLocalNotifChanges.EarliestStartDate = new Date(oNewDate);
				}
				DataHandler
				.saveLocalChangesForNotification(oViewModel, oServiceOrder, oLocalNotifChanges)
				.then(function() {
					DataHandler._mapNotification(oLocalSOChanges,oServiceOrder,oLocalNotifChanges);
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, "0000", oLocalSOChanges);
					DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
					this.getView().byId("PC1").setStartDate(this._getMonday(oNewDate));
				}.bind(this));
			} else {
				DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation, oLocalSOChanges)
				.then(function() {
					DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
					this.getView().byId("PC1").setStartDate(this._getMonday(oNewDate));
					this._initializeFields();
					oReasonField.setValue('');
				}.bind(this));
			}
			
			this._oDialog.close();
		},
		
		_initializeFields: function() {
			var oPopupModel = this._oDialog.getModel("popupModel");
			if (!oPopupModel) {
				oPopupModel = new sap.ui.model.json.JSONModel({saveEnabled: false});
				this._oDialog.setModel(oPopupModel, "popupModel");
			} else {
				oPopupModel.setProperty("/saveEnabled", false);
			}
		},
		
		handleDelete: function (oEvent) {
			var oViewModel = oEvent.getSource().getBindingContext().getModel();
			var oServiceOrder = oEvent.getSource().getBindingContext().getObject();
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation);

			if (!oLocalChanges.IsNotification) {
				DataHandler
					.removeLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation, oLocalChanges)
					.then(function () {
						DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
						this.getView().byId("PC1").setStartDate(this._getMonday(new Date(oLocalChanges.start)));
					}.bind(this));
			}
			else {
				oLocalChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oServiceOrder.serviceOrderNumber);
				DataHandler
					.removeLocalChangesForNotification(oViewModel, oServiceOrder.serviceOrderNumber)
					.then(function () {
						DataHandler.removeLocalChangesForServiceOperation(oViewModel, oServiceOrder.serviceOrderNumber, oServiceOrder.operation, oLocalChanges)
						DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
						this.getView().byId("PC1").setStartDate(this._getMonday(new Date(oLocalChanges.start)));
					}.bind(this));
			}
		},

		displayInfo: function (sWorkcenter, sTurbine) {
			var sSelectedKey = this.getView().getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab");
			if (sSelectedKey === 'workcenterKey') {
				return sTurbine;
			} else {
				return sWorkcenter;
			}
		},

		getVisible: function (sValue) {
			return sValue && sValue.length > 0 ? true : false;
		},
		
		getVisibleWc: function (sValue) {
			var sSelectedKey = this.getView().getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab");
			if (sSelectedKey === 'turbineKey') {
				return true;
			} else {
				return false;
			}
		},
		
		getVisiblePad: function (sValue) {
			var sSelectedKey = this.getView().getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/WvSelectedTab");
			if (sSelectedKey === 'workcenterKey') {
				return true;
			} else {
				return false;
			}
		},

		handleDateChange: function (oEvent) {
			this.getView().byId("searchNotificationText").setValue("");
			this.getView().byId("searchTurbineText").setValue("");
			this.getView().byId("searchCustomerText").setSelectedKey("all");
			this._hideAppointments("");
			this._getAppointmentsByTurbine("");
			this._getAppointmentsByCustomer("all");
		},

		handleSearchNotification: function (oEvent) {
			var sQuery = oEvent.getParameter("newValue").toLowerCase();
			this._hideAppointments(sQuery);
		},

		_hideAppointments: function (sQuery) {
			var oCalendar = this.getView().byId("PC1");
			if (sQuery.length > 2) {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					var aAppointments = oRow.getAppointments();
					_.forEach(aAppointments, function (oAppointment) {
						if (oAppointment.getTitle().toLowerCase().indexOf(sQuery) === -1) {
							$("#" + oAppointment.getId()).hide();
						} else {
							$("#" + oAppointment.getId()).show();
						}
					});
				});
			} else {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					var aAppointments = oRow.getAppointments();
					_.forEach(aAppointments, function (oAppointment) {
						$("#" + oAppointment.getId()).show();
					});
				});
			}
		},

		handleSearchByCustomer: function (oEvent) {
			// var sQuery = oEvent.getParameter("newValue").toLowerCase();
			var sQuery = oEvent.getSource().getSelectedItem().getText().toLowerCase();
			this._getAppointmentsByCustomer(sQuery);
		},

		handleSearchByTurbine: function (oEvent) {
			var sQuery = oEvent.getParameter("newValue").toLowerCase();
			this._getAppointmentsByTurbine(sQuery);
		},

		_getAppointmentsByTurbine: function (sQuery) {
			var oCalendar = this.getView().byId("PC1");
			if (sQuery.length > 2) {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					var aAppointments = oRow.getAppointments();
					if (oRow.getTitle().toLowerCase().indexOf(sQuery) === -1) {
						$("#" + oRow.getId() + '-CLI').hide();
					} else {
						$("#" + oRow.getId() + '-CLI').show();
					}
				});
			} else {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					$("#" + oRow.getId() + '-CLI').show();
				});
			}
		},

		_getAppointmentsByCustomer: function (sQuery) {
			var oCalendar = this.getView().byId("PC1");
			if (sQuery !== "all") {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					var aAppointments = oRow.getAppointments();
					_.forEach(aAppointments, function (oAppointment) {
						if (oAppointment.getCustomData()[0].getValue().toLowerCase().indexOf(sQuery) === -1) {
							$("#" + oAppointment.getId()).hide();
						} else {
							$("#" + oAppointment.getId()).show();
						}
					});
				});
			} else {
				var aRows = oCalendar.getAggregation("rows");
				_.forEach(aRows, function (oRow) {
					var aAppointments = oRow.getAppointments();
					_.forEach(aAppointments, function (oAppointment) {
						$("#" + oAppointment.getId()).show();
					});
				});
			}
		},
		
		_onIncompletePress: function(oEvent) {
			ToolbarHandler.onIncompletePress(oEvent,this);
		},
		
		_onNotificationsPress: function(oEvent) {
			ToolbarHandler.onNotificationsPress(oEvent,this);
		},
		
		onAcceptPress: function(oEvent) {
			ToolbarHandler.onAcceptPress(oEvent,this);
		},
		_setBubbleClass: function(aList) {
			aList && aList.length > 0 ? this.getView().byId("notificationWvBtn").addStyleClass("bubble") : 
										this.getView().byId("notificationWvBtn").removeStyleClass("bubble");
			return " ";
		},
		
		_setBubbleClassInc: function(aList) {
			aList && aList.length > 0 ? this.getView().byId("incompleteWvBtn").addStyleClass("bubble") : 
										this.getView().byId("incompleteWvBtn").removeStyleClass("bubble");
			return " ";
		},
		
		// handlePressTodayToolbar: function (oEvent) {
		// 	DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"), "Today");
		// },
		
		// handlePress1WeekToolbar: function (oEvent) {
		// 	DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"), "Week");
		// },
		
		// handlePress3WeeksToolbar: function (oEvent) {
		// 	DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"), "Weeks");
		// }

	});
}, /* bExport= */ true);