/*global moment, _ */
sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"../model/DataHandler",
	"../libs/lodash.min",
	"../utils/Random"
], function(BaseController, MessageBox, Utilities, History, DataHandler, NameToAvoidNamingConflictsLodash, Random) {
	"use strict";

	return BaseController.extend("plancalendar.controller.Settings", {
		_oSiteInput: null,
		returnToSettings: false,
		oResourceModel: null,
		
		handleRouteMatched: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var bIsInitialized = oViewModel.getProperty("/dataInitialized");
			var oComponent = this.getOwnerComponent();
			this.oResourceModel = oComponent.getModel("i18n").getResourceBundle();
			
			var sId;
			if (oEvent.getParameter("data") && oEvent.getParameter("data").id && oEvent.getParameter("data").id === "new") {
				this.returnToSettings = true;
				this.getView().byId("TopCell").setTitle(this.oResourceModel.getText("createSiteTxt"));
				this.getView().byId("CancelButton").setEnabled(true);
			} else if (oEvent.getParameter("data") && oEvent.getParameter("data").id) {
				sId = oEvent.getParameter("data").id;
				this.returnToSettings = true;
				this.getView().byId("TopCell").setTitle(this.oResourceModel.getText("editSiteTxt"));
				this.getView().byId("CancelButton").setEnabled(true);
			} else {
				this.getView().byId("TopCell").setTitle(this.oResourceModel.getText("createSiteToWorkOnTxt"));
			}
			this._oSiteNameInput.setValue(null);
			this._oHoursPerDayInput.setValue(null);
			this.getView().byId("SiteIdErrorMsg").setVisible(false);
			this.getView().byId("WorkcenterErrorMsg").setVisible(false);
			this._oSiteInput.removeAllTokens();
			this._oWorkcenterInput.removeAllTokens();
			if (!bIsInitialized) {
				DataHandler.initializeData(this.getView()).then(function(bResult) {
					if (bResult) {
						if (sId) {
							this._loadData(sId);
						}
					} else {
						DataHandler.saveSettings(DataHandler.getInitialUsersettings());
					}
					
				}.bind(this));
			}
			oViewModel.setProperty("/ApplicationBusy", false);
		},
		_loadData: function(sSavedSiteId) {
			var oViewModel = this.getView().getModel("viewModel");
			var aSavedSites = oViewModel.getProperty("/UserSettings/SavedSites");
			var iIndex = _.findIndex(aSavedSites, { SiteId: sSavedSiteId });
			if (iIndex < 0) {
				return;
			}
			var oSite = aSavedSites[iIndex];
			
			this._oSiteInput.setBusy(true);
			this._oWorkcenterInput.setBusy(true);
			this._oSiteNameInput.setValue(oSite.SiteName);
			this._oHoursPerDayInput.setValue(oSite.HoursPerDay);
			this._oSiteId.setText(oSite.SiteId);
			var aWorkcenterPromises = _.map(oSite.Workcenters, function(oWorkcenter) {
				return new Promise(function(fResolve, fReject) {
					DataHandler.lookupWorkcenterId(this.getView().getModel("backend"), oWorkcenter.WorkcenterId).then(function(aResults) {
						if (aResults.length > 0) {
							var oToken = this._workcenterToToken(aResults[0]);
							this._oWorkcenterInput.addToken(oToken);
							fResolve();
						}
					}.bind(this), fReject);
				}.bind(this));
			}.bind(this));
			var aSitePromises = _.map(oSite.Sites, function(sSiteId) {
				return new Promise(function(fResolve, fReject) {
					DataHandler.lookupSiteId(this.getView().getModel("backend"), sSiteId).then(function(aResults) {
						this._oSiteInput.addToken(this._siteIdToToken(sSiteId, aResults.length));
						fResolve();
					}.bind(this), fReject);
				}.bind(this));
			}.bind(this));
			Promise.all(aWorkcenterPromises.concat(aSitePromises)).then(function() {
				this._oSiteInput.setBusy(false);
				this._oWorkcenterInput.setBusy(false);
				this._onChange();
			}.bind(this));
		},
		_siteIdToToken: function(sSiteId, iTurbineCount) {
			return new sap.m.Token({text: sSiteId + " (" + iTurbineCount + " turbines)", key: sSiteId});
		},
		_workcenterToToken: function(oWorkcenter) {
			return new sap.m.Token({text: oWorkcenter.WorkcenterText + " (" + oWorkcenter.WorkcenterId + ")", key: oWorkcenter.WorkcenterId + "$" + oWorkcenter.WorkcenterText});
		},
		_save: function() {
			return new Promise(function(fResolve, fReject) {
				var oViewModel = this.getView().getModel("viewModel");
				var oUserSettings = oViewModel.getProperty("/UserSettings");
				if (!oUserSettings) {
					oUserSettings = DataHandler.getInitialUsersettings();
				}
				var sSiteId = this._oSiteId.getText() ? this._oSiteId.getText() : Random.generateUniqueId();
				var fHoursPerDay = parseFloat(this._oHoursPerDayInput.getValue());
				if (typeof fHoursPerDay !== 'number' || fHoursPerDay <= 0 || fHoursPerDay > 24) {
					fHoursPerDay = 7.0;
				}
				
				var oSite = {
					SiteId: sSiteId,
					SiteName: this._oSiteNameInput.getValue(),
					Sites: _.map(this._oSiteInput.getTokens(), function(oToken) { return oToken.getKey(); }),
					HoursPerDay: fHoursPerDay,
					Workcenters: _.map(this._oWorkcenterInput.getTokens(), function(oToken) { 
						var aInfo = oToken.getKey().split("$");
						return { WorkcenterId: aInfo[0], WorkcenterText: aInfo[1] };
					})
				};
				
				var aSavedSites = oUserSettings.SavedSites;
				if (!aSavedSites) {
					aSavedSites = [];
				}
				var iIndex = _.findIndex(aSavedSites, { SiteId: oSite.SiteId });
				if (iIndex >= 0) {
					aSavedSites[iIndex].SiteName = oSite.SiteName;
					aSavedSites[iIndex].Sites = oSite.Sites;
					aSavedSites[iIndex].Workcenters = oSite.Workcenters;
					aSavedSites[iIndex].HoursPerDay = oSite.HoursPerDay;
					oUserSettings.LocalChanges = aSavedSites[iIndex].LocalChanges;
					oUserSettings.SavedSites = aSavedSites;
				} else {
					aSavedSites.push(oSite);
				}
				
				if (!oUserSettings.SiteId || oUserSettings.SiteId === oSite.SiteId) {
					oUserSettings.SiteId = oSite.SiteId;
					oUserSettings.SiteName = oSite.SiteName;
					oUserSettings.Sites = oSite.Sites;
					oUserSettings.Workcenters = oSite.Workcenters;
					oUserSettings.HoursPerDay = oSite.HoursPerDay;
				}
				oViewModel.setProperty("/UserSettings", oUserSettings);
				DataHandler.saveSettings(oUserSettings).then(function() {
					DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
					fResolve();
				}.bind(this), fReject);
			}.bind(this ));
		},
		_onSavePress: function(oEvent) {
			oEvent.getSource().getModel("viewModel").setProperty("/ApplicationBusy", true);
			setTimeout(function() {
				this._save().then(this._navigate.bind(this));
			}.bind(this), 100);
			
		},
		
		_navigate: function(oEvent) {
			if (this.returnToSettings) {
				this.oRouter.navTo("ViewSettings"); 
			} else {
				this.oRouter.navTo("DayView"); 	
			}
		},
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("Settings").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			
			this._oSiteInput = this.getView().byId("SiteInput");
			this._oSiteId = this.getView().byId("SiteId");
			this._oWorkcenterInput = this.getView().byId("WorkcenterInput");
			this._oSiteNameInput = this.getView().byId("SiteNameInput");
			this._oHoursPerDayInput = this.getView().byId("HoursPerDayInput");
			this._oSiteInput.addValidator(this._validateSiteIds.bind(this));
			this._oWorkcenterInput.addValidator(this._validateWorkcenterIds.bind(this));
		},
		
		_validateSiteIds: function(args) {
			this._oSiteInput.setBusy(true);
			this.getView().byId("SiteIdErrorMsg").setVisible(false);
			var siteIdText = args.text.toUpperCase().replace(/\s/g,'');
//			DataHandler.lookupSiteId(this.getView().getModel("backend"), args.text).then(function(aResults) {
			DataHandler.lookupSiteId(this.getView().getModel("backend"), siteIdText).then(function(aResults) {
				if (aResults.length === 0) {
//					this.getView().byId("SiteIdErrorMsg").setText(this.oResourceModel.getText("countFindSiteTxt") + ' ' + args.text + ". " +  this.oResourceModel.getText("incorrectSiteIdMsg"));
					this.getView().byId("SiteIdErrorMsg").setText(this.oResourceModel.getText("countFindSiteTxt") + ' ' + siteIdText + ". " +  this.oResourceModel.getText("incorrectSiteIdMsg"));
					this.getView().byId("SiteIdErrorMsg").setVisible(true);
				} else {
//					args.asyncCallback(this._siteIdToToken(args.text, aResults.length));
					args.asyncCallback(this._siteIdToToken(siteIdText, aResults.length));
				}
				this._oSiteInput.setBusy(false);
			}.bind(this), function(oError) {
				var oResponseText = JSON.parse(oError.responseText);
				this.getView().byId("SiteIdErrorMsg").setText(oResponseText.error.message.value);
				this.getView().byId("SiteIdErrorMsg").setVisible(true);
				this._oSiteInput.setBusy(false);
			}.bind(this)
			);
			return sap.m.MultiInput.WaitForAsyncValidation;
		},
		
		_validateWorkcenterIds: function(args) {
			this._oWorkcenterInput.setBusy(true);
			this.getView().byId("WorkcenterErrorMsg").setVisible(false);
			DataHandler.lookupWorkcenterId(this.getView().getModel("backend"), args.text).then(function(aResults) {
				if (aResults.length === 0) {
					this.getView().byId("WorkcenterErrorMsg").setText(this.oResourceModel.getText("incorrectWCIdTxt") + ' ' + args.text + ". " +  this.oResourceModel.getText("incorrectWcIdMsg"));
					this.getView().byId("WorkcenterErrorMsg").setVisible(true);
				} else {
					args.asyncCallback(this._workcenterToToken(aResults[0]));
				}
				this._oWorkcenterInput.setBusy(false);
			}.bind(this), function(oError) {
				var oResponseText = JSON.parse(oError.responseText);
				this.getView().byId("WorkcenterErrorMsg").setText(oResponseText.error.message.value);
				this.getView().byId("WorkcenterErrorMsg").setVisible(true);
				this._oWorkcenterInput.setBusy(false);
			}.bind(this));
			return sap.m.MultiInput.WaitForAsyncValidation;
		},
		
		_onChange: function(oEvent) {
			this.getView().byId("SaveButton").setEnabled(this._isFormValid());
		},
		
		_onAddToken: function(oEvent) {
			this.getView().byId("SiteIdErrorMsg").setVisible(false);
		},
		
		_onAddWc: function(oEvent) {
			this.getView().byId("WorkcenterErrorMsg").setVisible(false);
		},
		
		_isFormValid: function() {
			return this._oSiteInput.getTokens().length > 0 && this._oWorkcenterInput.getTokens().length > 0 && this._oSiteNameInput.getValue().length > 0;
		}
	});
}, /* bExport= */ true);
