sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"../model/DataHandler",
	"../libs/lodash.min",
	"../libs/html2pdf.bundle.min",
	"../libs/jspdf.min",
	"../libs/jspdf.plugin.autotable.min",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet",
	"../utils/toolbarHandler",
	// "../libs/xlsx-style/xlsx.full.min",
	"../libs/xlsx.full.min",
	"../libs/FileSaver.min",
	"../utils/Random"
], function(BaseController, MessageBox, Utilities, History, DataHandler, NameToAvoidNamingConflictsLodash, NameToAvoidNamingConflictsHtml2pdf, 
NameToAvoidNamingConflictsJSPdf, NameToAvoidNamingConflictsAutoTable, Fragment, MessageToast, Spreadsheet, ToolbarHandler, NameToAvoidNamingConflictsSheetJS, NameToAvoidNamingConflictsFileSaver, Random) {
	
	"use strict";
	
	/* global XLSX:true */

	return BaseController.extend("plancalendar.controller.DayView", {
		
		oResourceModel: null,
		
		handleRouteMatched: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var oComponent = this.getOwnerComponent();
			this.oResourceModel = oComponent.getModel("i18n").getResourceBundle();
			var bIsInitialized = oViewModel.getProperty("/IsDataInitialized");
			if (!bIsInitialized) {
				DataHandler.initializeData(this.getView()).then(function(bResult) {
					if (!bResult) {
						this.oRouter.navTo("Settings");
					}
				}.bind(this));
			}
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/selectedTab", 'EditPoDKey');
			oViewModel.setProperty("/ApplicationBusy", false);
		},
		
		handleWorkcenterSelectionChange: function(oEvent) {
			var oContext = oEvent.getParameter("selectedItem").getBindingContext("viewModel");
			var sKey = oContext.getProperty("key");
			var sKeyText = oContext.getProperty("name");
			
			this._lookupServiceTeam(oEvent).then(function(oChanged) {
				var oViewModel = oContext.getModel();
				var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId);
				oLocalChanges.WorkcenterId = oChanged.WorkcenterId;
				oLocalChanges.WorkcenterText = sKeyText;
				oLocalChanges.Team = oChanged.Team;
				DataHandler
					.saveLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId, oLocalChanges)
					.then(function() {
						DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
					}.bind(this));
			}.bind(this));
		},
		handleNotificationWorkcenterSelectionChange: function(oEvent) {
			var oContext = oEvent.getParameter("selectedItem").getBindingContext("viewModel");
			var sKey = oContext.getProperty("key");
			var sKeyText = oContext.getProperty("name");
			
			this._lookupServiceTeam(oEvent).then(function(oChanged) {
				var oViewModel = oContext.getModel();
				var oLocalChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oChanged.OrderId);
				oLocalChanges.WorkcenterId = oChanged.WorkcenterId;
				oLocalChanges.WorkcenterText = sKeyText;
				oLocalChanges.Team = oChanged.Team;
				DataHandler
					.saveLocalChangesForNotification(oViewModel, oChanged.OrderId, oLocalChanges)
					.then(function() {
						DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"));
					}.bind(this));
			}.bind(this));
		},
		navToPrevDay: function(oEvent) {
			var oViewModel = oEvent.getSource().getModel("viewModel");
			var dToday = oViewModel.getProperty("/Data/TodaysDate");
			var dCurrentDay = _.cloneDeep(dToday);
			var dDayBefore = new Date(dCurrentDay.setDate(dCurrentDay.getDate() - 1));
			oViewModel.setProperty("/Data/TodaysDate", dDayBefore);
			this._setDatePickerVisibility(dToday,dDayBefore);                
			DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
		},
		navToNextDay: function(oEvent) {
			var oViewModel = oEvent.getSource().getModel("viewModel");
			var dToday = oViewModel.getProperty("/Data/TodaysDate");
			var dCurrentDay = _.cloneDeep(dToday);
			var dDayAfter = new Date(dCurrentDay.setDate(dCurrentDay.getDate() + 1));
			oViewModel.setProperty("/Data/TodaysDate", dDayAfter);
			this._setDatePickerVisibility(dToday,dDayAfter); 
			DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
		},
		_onButtonPress: function(oEvent) {
			this.getView().getModel("viewModel").setProperty("/ApplicationBusy", true);
			var oViewModel = oEvent.getSource().getModel("viewModel");
			var oBackendModel = oEvent.getSource().getModel("backend");
			setTimeout(function() {
				DataHandler.reloadWeeklyServiceOperations(oViewModel, oBackendModel);
				this.oRouter.navTo("WeekView");
			}.bind(this), 100);
		},
		_onSettingsPress: function(oEvent) {
			return new Promise(function(fnResolve) {

				this.oRouter.navTo("ViewSettings");
			}.bind(this)).catch(function(err) {
				if (err !== undefined) {
					MessageBox.error(err.message);
				}
			});
		},
		_onReloadSapDataPress: function(oEvent) {
			DataHandler.initializeData(this.getView());			
		},		
		getGroupHeader: function (oGroup) {
			return new sap.m.GroupHeaderListItem( {
				title: oGroup.group,
				upperCase: false
			});
		},
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("DayView").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));

		},
		
		_onIncompletePress: function(oEvent) {
			ToolbarHandler.onIncompletePress(oEvent,this);
		},
		
		_onNotificationsPress: function(oEvent) {
			ToolbarHandler.onNotificationsPress(oEvent,this);
		},
		
		onAcceptPress: function(oEvent) {
			ToolbarHandler.onAcceptPress(oEvent,this);
		},
		
		handleIconTabBarSelect: function(oEvent) {
			var oViewModel = oEvent.getSource().getModel("viewModel");
			var oView = this.getView();
			var oBackendModel = oEvent.getSource().getModel("backend");
			var oUserSettings = oViewModel.getProperty("/UserSettings");
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			oViewModel.setProperty("/Data/ServiceOperationsFromDateRange/selectedTab", sSelectedKey);
			if(sSelectedKey === 'TasksCustomerPoDKey'){
				this._openCustomerHelp(oView,oEvent.getSource().getAggregation("_header"));
			} else if(sSelectedKey === 'TasksWorkcenterPoDKey'){
				this._openWorkcenterHelp(oView,oEvent.getSource().getAggregation("_header"));
			} else {
				if (this._oCustomerHelp && this._oCustomerHelp.isOpen()) {
					this._oCustomerHelp.close();
				} else if (this._oWorkcenterHelp && this._oWorkcenterHelp.isOpen()) {
					this._oWorkcenterHelp.close();
				}
			}
		},
		
		_openCustomerHelp: function(oView,oTab) {
			if (!this._oCustomerHelp) {
				Fragment.load({
					id: oView.getId(),
					name: "plancalendar.view.Customers", 
					controller: this
				}).then(function (oCustomerDialog) {
					this._oCustomerHelp = oCustomerDialog;
					oView.addDependent(this._oCustomerHelp);
					this._oCustomerHelp.openBy(oTab);
				}.bind(this));
			} else {
					this._oCustomerHelp.openBy(oTab);
			}
		},
		
		_openWorkcenterHelp: function(oView,oTab) {
			if (!this._oWorkcenterHelp) {
				Fragment.load({
					id: oView.getId(),
					name: "plancalendar.view.Workcenters", 
					controller: this
				}).then(function (oWorkcenterDialog) {
					this._oWorkcenterHelp = oWorkcenterDialog;
					oView.addDependent(this._oWorkcenterHelp);
					this._oWorkcenterHelp.openBy(oTab);
				}.bind(this));
			} else {
					this._oWorkcenterHelp.openBy(oTab);
			}
		},
		
		handleConfirmCustomers: function(oEvent) {
			var aSelectedItems = this.byId("customerList").getSelectedItems();
			var oBindingUnplaned = this.oView.byId("unplanedCustomerTable").getBinding("items");
			var oBindingPod = this.oView.byId("podCustomerTable").getBinding("items");
			var oBindingMoved = this.oView.byId("movedCustomerTable").getBinding("items");
			var oBindingNotif= this.oView.byId("NotificationCustomerTable").getBinding("items");
			var aFilter = [];
			var aWithNotificationFilter = [];
			var oWithNotificationFilter = new sap.ui.model.Filter("IsNotification", 'EQ', true);
			aWithNotificationFilter.push(oWithNotificationFilter);
			var aWithoutNotificationFilter = [];
			var oWithoutNotificationFilter = new sap.ui.model.Filter("IsNotification", 'EQ', false);
			aWithoutNotificationFilter.push(oWithoutNotificationFilter);
			aSelectedItems.forEach(function(oSelectedCustomer) {
				aFilter.push(new sap.ui.model.Filter("CustomerId", 'EQ', oSelectedCustomer.getDescription()));
				aWithNotificationFilter.push(new sap.ui.model.Filter("CustomerId", 'EQ', oSelectedCustomer.getDescription()));
				aWithoutNotificationFilter.push(new sap.ui.model.Filter("CustomerId", 'EQ', oSelectedCustomer.getDescription()));
			});
			oBindingUnplaned.filter(aFilter);
			oBindingPod.filter(aWithoutNotificationFilter);
			oBindingMoved.filter(aFilter);
			oBindingNotif.filter(aWithNotificationFilter);
			this._oCustomerHelp.close();
		},
		
		handleConfirmWorkcenter: function(oEvent) {
			var aSelectedItems = this.byId("workcenterList").getSelectedItems();
			var oBindingUnplaned = this.oView.byId("unplanedWorkcenterTable").getBinding("items");
			var oBindingPod = this.oView.byId("podWorkcenterTable").getBinding("items");
			var oBindingMoved = this.oView.byId("movedWorkcenterTable").getBinding("items");
			var oBindingNotif= this.oView.byId("NotificationWorkcenterTable").getBinding("items");
			var aFilter = [];
			var aWithNotificationFilter = [];
			var oWithNotificationFilter = new sap.ui.model.Filter("IsNotification", 'EQ', true);
			aWithNotificationFilter.push(oWithNotificationFilter);
			var aWithoutNotificationFilter = [];
			var oWithoutNotificationFilter = new sap.ui.model.Filter("IsNotification", 'EQ', false);
			aWithoutNotificationFilter.push(oWithoutNotificationFilter);
			aSelectedItems.forEach(function(oSelectedWorkcenter) {
				aFilter.push(new sap.ui.model.Filter("WorkcenterId", 'EQ', oSelectedWorkcenter.getDescription()));
				aWithNotificationFilter.push(new sap.ui.model.Filter("WorkcenterId", 'EQ', oSelectedWorkcenter.getDescription()));
				aWithoutNotificationFilter.push(new sap.ui.model.Filter("WorkcenterId", 'EQ', oSelectedWorkcenter.getDescription()));
			});
			oBindingUnplaned.filter(aFilter);
			oBindingPod.filter(aWithoutNotificationFilter);
			oBindingMoved.filter(aFilter);
			oBindingNotif.filter(aWithNotificationFilter);
			this._oWorkcenterHelp.close();
		},
		
		
		setVisibleForEditPlan: function(sKey) {
			return !sKey || sKey === 'EditPoDKey' ? true : false;
		},
		
		getStartedOrNot: function(bStarted) {
			return bStarted ? false : true;
		},
		
		setVisibleForChangedPlan: function(sKey) {
			return sKey && sKey === 'ChangedTasksPoDKey' ? true : false;
		},
		
		setVisibleForWorkcenterPlan: function(sKey) {
			return sKey && sKey === 'TasksWorkcenterPoDKey' ? true : false;
		},
		
		handleMoveDate: function(oEvent) {
			var oView = this.getView();
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			
			if (!this._oMoveFromDayDialog) {
				this._oMoveFromDayDialog = sap.ui.xmlfragment("plancalendar.view.MoveFromDay", this);
				oView.addDependent(this._oMoveFromDayDialog);
				this._oMoveFromDayDialog.setModel(oView.getModel("viewModel"));
			}
			var oMoveModel = new sap.ui.model.json.JSONModel({MoveSelected: false});
			
			this._oMoveFromDayDialog.setBindingContext(oContext);
			this._oMoveFromDayDialog.setModel(oMoveModel, "moveModel");
			this._oMoveFromDayDialog.open();
		},
		
		handleMoveAll: function(oEvent) {
			var oView = this.getView();
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			
			if (!this._oMoveAllDialog) {
				this._oMoveAllDialog = sap.ui.xmlfragment("plancalendar.view.MoveAll", this);
				oView.addDependent(this._oMoveAllDialog);
				this._oMoveAllDialog.setModel(oView.getModel("viewModel"));
			}
			var oMoveModel = new sap.ui.model.json.JSONModel({MoveSelected: false});
			
			this._oMoveAllDialog.setBindingContext(oContext);
			this._oMoveAllDialog.setModel(oMoveModel, "moveModel");
			this._oMoveAllDialog.open();
		},
		
		handlePressCloseMoveAll: function(oEvent) {
			if (this._oMoveAllDialog && this._oMoveAllDialog.isOpen()) {
				this._oMoveAllDialog.close();
			}
		},
		
		handlePressSaveMoveAll: function(oEvent) {
			var aServiceOperations = this.getView().getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var oLocalChanges
			// var oServiceOperation = oEvent.getSource().getBindingContext().getObject();
			var oMoveModel = oEvent.getSource().getModel("moveModel");
			var oViewModel = this.getView().getModel("viewModel");
			var dMovedDate = oMoveModel.getProperty("/MoveDate");
			dMovedDate = new Date(dMovedDate);
			dMovedDate.setHours(parseInt('00'));
			
			
			aServiceOperations && aServiceOperations.forEach(function(oServiceOperation) {
				if (oServiceOperation.IsNotification === false) {
					oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId);
					if (oMoveModel.getProperty("/MoveSelected")) {
						delete oLocalChanges.Removed;
						oLocalChanges.EarliestStartDate = dMovedDate;
						oLocalChanges.MoveReason = oMoveModel.getProperty("/MoveReason");
					} else if (oMoveModel.getProperty("/ClearSelected")) {
						delete oLocalChanges.Removed;
						delete oLocalChanges.EarliestStartDate;
						delete oLocalChanges.MoveReason;
					}
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId, oLocalChanges);
				}
			});
			
			DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
			this.handlePressCloseMoveAll();
		},
		
		handlePressCloseMoveFromDay: function(oEvent) {
			if (this._oMoveFromDayDialog && this._oMoveFromDayDialog.isOpen()) {
				this._oMoveFromDayDialog.close();
			}
		},
		
		handleAddUnplanned: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var aUnplanned = DataHandler.getLocalChangesUnplannedTasks(oViewModel);
			var newUnplanned = {
				ID: Random.generateUniqueId(),
				FuncLocDesc: "",
				OperationText: "",
				WorkcenterId: "",
				WorkcenterText: "",
				TeamArray: [],
				Team: "",
				Comment: "",
				EarliestStartDate: this.getView().getModel("viewModel").getProperty("/Data/TodaysDate")
			};
			DataHandler
				.saveLocalChangesUnplannedTasks(oViewModel, [...aUnplanned, newUnplanned])
				.then(function() { DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend")); }.bind(this));
		},
		
		handleUnplannedWorkcenterChanged: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			this._lookupServiceTeam(oEvent).then(this._saveUnplanned.bind(this));
			oViewModel.setProperty(oContext.getPath() + "/WorkcenterText", oEvent.getParameter("selectedItem").getText());
		},
		
		_lookupServiceTeam: function(oEvent) {
			return new Promise(function(fResolve, fReject) {
				var oViewModel = this.getView().getModel("viewModel");
				var oContext = oEvent.getSource().getBindingContext("viewModel");
				var oChanged = oContext.getObject();
				var sWorkcenterId = oEvent.getParameter("selectedItem").getBindingContext("viewModel").getProperty("key");
				var dTodaysDate = oViewModel.getProperty("/Data/TodaysDate");
				if (sWorkcenterId === "custom") {
					fResolve(oChanged);
				} else {
					DataHandler
						.lookupServiceTeam(this.getView().getModel("backend"), sWorkcenterId, dTodaysDate)
						.then(function(aServiceTeam) {
							if (aServiceTeam[0].Team && aServiceTeam[0].Team.split(",").length > 5) {
								oViewModel.setProperty(oContext.getPath() + "/Team", "");
								oViewModel.setProperty(oContext.getPath() + "/TeamArray",[]);
							}
							else if (aServiceTeam && aServiceTeam.length > 0) {
								oViewModel.setProperty(oContext.getPath() + "/Team", aServiceTeam[0].Team);
								oViewModel.setProperty(oContext.getPath() + "/TeamArray", _.map(aServiceTeam[0].Team.split(","), function(sTeamMember) { return { Initials: sTeamMember.trim() }; }));
							}
							fResolve(oChanged);
						}.bind(this),
						fReject);
				}
			}.bind(this));
		},
		
		handleUnplannedChanged: function(oEvent) {
			var oChanged = oEvent.getSource().getBindingContext("viewModel").getObject();
			this._saveUnplanned(oChanged);
		},
		
		_saveUnplanned: function(oChanged) {
			var oViewModel = this.getView().getModel("viewModel");
			var aUnplanned = DataHandler.getLocalChangesUnplannedTasks(oViewModel);
			var iIndex = _.findIndex(aUnplanned, { ID: oChanged.ID });
			aUnplanned.splice(iIndex, 1, oChanged);
			DataHandler
				.saveLocalChangesUnplannedTasks(oViewModel, aUnplanned)
				.then(function() { DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend")); }.bind(this));
		},
		
		handleDeleteUnplanned: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var oChanged = oEvent.getSource().getBindingContext("viewModel").getObject();
			var aUnplanned = DataHandler.getLocalChangesUnplannedTasks(oViewModel);
			var iIndex = _.findIndex(aUnplanned, { ID: oChanged.ID });
			aUnplanned.splice(iIndex, 1);
			DataHandler
				.saveLocalChangesUnplannedTasks(oViewModel, aUnplanned)
				.then(function() { DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend")); }.bind(this));
		},
		
		handlePressSaveMoveFromDay: function(oEvent) {
			var oServiceOperation = oEvent.getSource().getBindingContext().getObject();
			var oMoveModel = oEvent.getSource().getModel("moveModel");
			var oViewModel = this.getView().getModel("viewModel");
			var dMovedDate = oMoveModel.getProperty("/MoveDate");
			dMovedDate = new Date(dMovedDate);
			dMovedDate.setHours(parseInt('00'));
			
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId);
			
			if (oServiceOperation.IsNotification === true) {
				var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oServiceOperation.OrderId)
			}
			
			if (oMoveModel.getProperty("/MoveSelected")) {
				oLocalChanges.EarliestStartDate = dMovedDate;
				delete oLocalChanges.Removed;
				oLocalChanges.MoveReason = oMoveModel.getProperty("/MoveReason");
				if (oServiceOperation.IsNotification) {
					oLocalNotifChanges.EarliestStartDate = dMovedDate;
					DataHandler.saveLocalChangesForNotification(oViewModel, oServiceOperation, oLocalNotifChanges);
				}
			} else if (oMoveModel.getProperty("/RemoveSelected") && oServiceOperation.IsNotification === false) {
				oLocalChanges.Removed = true;
				delete oLocalChanges.EarliestStartDate;
				oLocalChanges.MoveReason = oMoveModel.getProperty("/MoveReason");
			} else if (oMoveModel.getProperty("/RemoveSelected") && oServiceOperation.IsNotification === true) {
				DataHandler.removeLocalChangesForNotification(oViewModel, oServiceOperation.OrderId)
				.then(function () {
						DataHandler.removeLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId, oLocalChanges)
					}.bind(this));
			} else {
				delete oLocalChanges.Removed;
				delete oLocalChanges.EarliestStartDate;
				delete oLocalChanges.MoveReason;
			}
			DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId, oLocalChanges)
				.then(function() {
					DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
					this.handlePressCloseMoveFromDay();
				}.bind(this));
		},
		
		handleDownload: function(oEvent) {
			var that = this;
			if (!this._actionSheet) {
				this._actionSheet = new sap.m.ActionSheet({
		           buttons: [
		            new sap.m.Button( {
		                text : that.oResourceModel.getText("exportExcelBtn"),
		                icon : "sap-icon://excel-attachment",
		                press:  [ that._onExportToXls, that ]}),
		            new sap.m.Button( {
		                text : that.oResourceModel.getText("exportPDFBtn"),
		                icon : "sap-icon://pdf-attachment",
		                press:  [ that._onExportToPdf, that ]})               
		           ],
		           placement: sap.m.PlacementType.Top,
		           });
				this.getView().addDependent(this._actionSheet);
			}

			this._actionSheet.openBy(oEvent.getSource());
		},
		
		_setDatePickerVisibility: function(dToday,dDay) {
			var iDateDiffTime = new Date().getTime() - dDay.getTime();
			var iDateDiffDays = iDateDiffTime / (1000 * 3600 * 24); 
			if (iDateDiffDays < -21) {
				this.oView.byId("navPrevDayId").setVisible(true);
				this.oView.byId("navNextDayId").setVisible(false);
			}
			else if (iDateDiffDays > 21) {
				this.oView.byId("navPrevDayId").setVisible(false);
				this.oView.byId("navNextDayId").setVisible(true);
			}
			else {
				this.oView.byId("navPrevDayId").setVisible(true);
				this.oView.byId("navNextDayId").setVisible(true);
			}
		},
		
		handleBundle: function (oEvent) {
			var oView = this.getView();
			var oViewModel = oView.getModel("viewModel");
			var oBackendModel = oView.getModel("backend");
			var oButton = oEvent.getSource();
			var oNotification = oButton.getBindingContext("viewModel").getObject();
			var sEquipmentId = oNotification.EquipmentId;

			DataHandler.getServiceOperationsForEquipment(oBackendModel,sEquipmentId).then(function(aResult) {
					aResult = this._excludeUserStatus(aResult);
					oViewModel.setProperty("/Data/BundledOperations", aResult);
					var oList = oView.byId("BundledListId");
					oList.removeSelections();
					var aListItems = oList.getItems();
					if (oNotification.BundledSO) {
						oNotification.BundledSO.forEach(function(oBundledSO) {
							var iIndex = _.findIndex(aListItems, function(oItem) {
							  return oItem.getDescription().split('/')[0] === oBundledSO.OrderId;
							});
							if (iIndex >= 0) {
		    					oList.setSelectedItem(aListItems[iIndex]);
		    				} 
						});
					}
				}.bind(this));

			if (!this._oBundlePopover) {
				Fragment.load({
					id: oView.getId(),
					name: "plancalendar.view.BundleNotification", 
					controller: this
				}).then(function (oPopover) {
					this._oBundlePopover = oPopover;
					oView.addDependent(this._oBundlePopover);
					this._oBundlePopover.setBindingContext(oButton.getBindingContext("viewModel"));
					this._oBundlePopover.openBy(oButton);
					
				}.bind(this));
			} else {
				if (this._oBundlePopover.isOpen()) {
					this._oBundlePopover.close();
				} else {
					this._oBundlePopover.setBindingContext(oButton.getBindingContext("viewModel"));
					this._oBundlePopover.openBy(oButton);
				}
			}
		},
		
		handlePressClearLocalChanges: function() {
			var oViewModel = this.getView().getModel("viewModel");
			var oUserSettings = oViewModel.getProperty("/UserSettings");
			oUserSettings.LocalChanges = {};
			DataHandler.saveSettings(oUserSettings).then(function() {
				DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
			}.bind(this));
		},
		
		handleAddToNotification: function(oEvent) {
			var oViewModel = oEvent.getSource().getBindingContext().getModel();
			var oNotification = oEvent.getSource().getBindingContext().getObject();
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oNotification.OrderId);
			var oLocalSOChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oNotification.OrderId, oNotification.OperationId);
			oNotification.BundledSO = [];
			var aSelectedItems = this.byId("BundledListId").getSelectedItems();
			
			_.forEach(aSelectedItems, function (oSelectedItem) {
				var oBundledSO = {};
					oBundledSO.OrderId = oSelectedItem.getDescription().split('/')[0];
					oBundledSO.OperationId = oSelectedItem.getDescription().split('/')[1];
					oBundledSO.SOText = oSelectedItem.getTitle();
					oNotification.BundledSO.push(oBundledSO);
				});
			
			oLocalNotifChanges.BundledSO = oNotification.BundledSO;
			
			DataHandler
				.saveLocalChangesForNotification(oViewModel, oNotification, oLocalNotifChanges)
				.then(function() {
					DataHandler._mapNotification(oLocalSOChanges,oNotification,oLocalNotifChanges);
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oNotification.OrderId, "0000", oLocalSOChanges);
					DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
				}.bind(this));
			MessageToast.show(this.oResourceModel.getText("succBundTxt"));
			this._oBundlePopover.close();
		},
		
		handleClearAddToNotification: function(oEvent) {
			this.getView().byId("BundledListId").removeSelections();
		},
		
		handlePressRevertWorkcenter: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			var oViewModel = oContext.getModel();
			var oServiceOperation = oEvent.getSource().getBindingContext("viewModel").getObject();
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId);
			delete oLocalChanges.WorkcenterId;
			delete oLocalChanges.WorkcenterText;
			delete oLocalChanges.Team;
			DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId, oLocalChanges)
				.then(function() {DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"))}.bind(this));
		},
		
		_excludeUserStatus: function(aResult) {
			return _.remove(aResult, function (o) {
				return o.UserStatus !== 'Y1IS' 
			});
		},
		
		setBundledBtnText: function(aBudledSO) {
			return aBudledSO && aBudledSO.length > 0 ? this.oResourceModel.getText("alreadyBundTxt") : this.oResourceModel.getText("bundSO");
		},
		
		setBundledBtnEna: function(aBudledSO) {
			return aBudledSO && aBudledSO.length > 0 ? false : true;
		},
		
		handleDeleteSOFromBundle: function (oEvent) {
			var oNotification = oEvent.getSource().getBindingContext("viewModel").getObject();
			var oDeletedSO = oEvent.getParameter("listItem").getBindingContext("viewModel").getObject();
			var oViewModel = oEvent.getSource().getBindingContext("viewModel").getModel();
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oNotification.OrderId);
			var oLocalSOChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oNotification.OrderId, oNotification.OperationId);
			
			if (oNotification.BundledSO) {
    			var iIndex = _.findIndex(oNotification.BundledSO, {OrderId: oDeletedSO.OrderId, OperationId: oDeletedSO.OperationId});
    			if (iIndex >= 0) {
    				oNotification.BundledSO.splice(iIndex, 1);
    			} 
    		}
			
			oLocalNotifChanges.BundledSO = oNotification.BundledSO;
			
			DataHandler
				.saveLocalChangesForNotification(oViewModel, oNotification, oLocalNotifChanges)
				.then(function() {
					DataHandler._mapNotification(oLocalSOChanges,oNotification,oLocalNotifChanges);
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oNotification.OrderId, "0000", oLocalSOChanges);
					DataHandler.reloadWeeklyServiceOperations(oViewModel, this.getView().getModel("backend"));
				}.bind(this));
			MessageToast.show(this.oResourceModel.getText("succRemovedfromBund"));
		},
		
		_onExportToXls: function (oController) {
			
			var oFile = this._buildExcelData();
			
		    function s2ab(s) {
		        var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
		        var view = new Uint8Array(buf); //create uint8array as viewer
		        for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
		        return buf;
		    }
		    
		    saveAs(new Blob([s2ab(oFile)], {
		        type: "application/octet-stream"
		    }), 'dailyplan.xlsx');
		    
		},
		
		_buildExcelData: function() {
			var oDataSource = this.getView().byId("PODTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var oDataSourceNotifications = this.getView().byId("PODNotificationsTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var oDataSourceUnplanned = this.getView().byId("UnplannedTable").getModel("viewModel").getProperty("/Data/UnplannedForToday");
			var oDataSourceChangedTasks = this.getView().byId("ChangedTaskTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/changedFromDay");
			var oDataSourceNotificationsChangedTasks = this.getView().byId("ViewChangesNotificationsTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var oDataSourceMovedFromToday = this.getView().byId("MovedTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/movedFromDay");
			
			var oDataSourceUnplannedByWorkcenter = this.getView().byId("unplanedWorkcenterTable").getItems();
			var aDataSourceUnplannedByWorkcenter = [];
			oDataSourceUnplannedByWorkcenter.forEach(function(oItem) {
				aDataSourceUnplannedByWorkcenter.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourcePerWorkcenter = this.getView().byId("podWorkcenterTable").getItems();
			var aDataSourcePerWorkcenter = [];
			oDataSourcePerWorkcenter.forEach(function(oItem) {
				aDataSourcePerWorkcenter.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceChangedTasksByWorkcenter = this.getView().byId("movedWorkcenterTable").getItems();
			var aDataSourceChangedTasksByWorkcenter = [];
			oDataSourceChangedTasksByWorkcenter.forEach(function(oItem) {
				aDataSourceChangedTasksByWorkcenter.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceNotificationsByWorkcenter = this.getView().byId("NotificationWorkcenterTable").getItems();
			var aDataSourceNotificationsByWorkcenter = [];
			oDataSourceNotificationsByWorkcenter.forEach(function(oItem) {
				aDataSourceNotificationsByWorkcenter.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceUnplannedByCustomer = this.getView().byId("unplanedCustomerTable").getItems();
			var aDataSourceUnplannedByCustomer = [];
			oDataSourceUnplannedByCustomer.forEach(function(oItem) {
				aDataSourceUnplannedByCustomer.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceByCustomer = this.getView().byId("podCustomerTable").getItems();
			var aDataSourceByCustomer = [];
			oDataSourceByCustomer.forEach(function(oItem) {
				aDataSourceByCustomer.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceChangedTasksByCustomer = this.getView().byId("movedCustomerTable").getItems();
			var aDataSourceChangedTasksByCustomer = [];
			oDataSourceChangedTasksByCustomer.forEach(function(oItem) {
				aDataSourceChangedTasksByCustomer.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oDataSourceNotificationsByCustomer = this.getView().byId("NotificationCustomerTable").getItems();
			var aDataSourceNotificationsByCustomer = [];
			oDataSourceNotificationsByCustomer.forEach(function(oItem) {
				aDataSourceNotificationsByCustomer.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var oViewModel = this.getView().getModel("viewModel");
			var selectedTab = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/selectedTab");

			if (typeof(selectedTab) == 'undefined') {
				selectedTab = 'EditPoDKey';
			}

			var oNewBook = XLSX.utils.book_new();
		    oNewBook.Props = {
			         Title: "Plan of the Day",
			         Subject: "Plan of Day",
			         Author: "",
			         CreatedDate: new Date()
		    };
		    
		    oNewBook.SheetNames.push("Daily Plan");

			// Prep Header info
			var oView = this.getView();
			var oViewModel = oView.getModel("viewModel");
//			var currentDay = new Date();
			var currentDay = oViewModel.getProperty("/Data/TodaysDate");
			
			var siteName = "Site name: " + oViewModel.getProperty("/UserSettings/SiteName");
		    var padList = "Site id/Pad id(s): " + oViewModel.getProperty("/UserSettings/Sites");
		    
		    var aExcelData = [
		        [siteName],
		    	[padList],  
		    	[currentDay],  
		        [], 
		        [] 
		    ]; //a row with 2 columns


			if (selectedTab === 'ChangedTasksPoDKey') {
				// Changed tasks
			    this._getExcelChanged(aExcelData,oDataSourceChangedTasks);

				// // Notifications added to plan + bundled tasks
			 //   this._getExcelNotifications(aExcelData,oDataSourceNotificationsChangedTasks);
			} else if (selectedTab === 'EditPoDKey' || selectedTab === 'ViewPoDKey') {
		        var aHeaderText = ['', 'TODAY`S PLANNED WORK			'];
				aExcelData.push(aHeaderText);
					
				// // Unplanned tasks
			 //   this._getExcelUnplaned(aExcelData,oDataSourceUnplanned);
	
				// Normal Service order operations
			    this._getExcelPod(aExcelData,oDataSource);
	
				// Moved from today
			    this._getExcelChanged(aExcelData,oDataSourceChangedTasks);
			    
			    // this._getExcelNotifications(aExcelData,oDataSourceNotifications);
	
			} else if (selectedTab === 'TasksWorkcenterPoDKey') {
		        var aHeaderText = ['', 'TODAY`S PLANNED WORK BY WORKCENTER			'];
				aExcelData.push(aHeaderText);
				
				if (this.getView().byId("workcenterList")) {
					var aSelectedWorkcenters = this.getView().byId("workcenterList").getSelectedItems();
					var aHeaderWcText = ['', 'SELECTED WORKCENTERS			'];
					aSelectedWorkcenters.forEach(function(oWorkcenter) {
						aHeaderWcText.push(oWorkcenter.getTitle());
					});
				}
				
				aExcelData.push(aHeaderWcText);
					
				// // Unplanned tasks
			 //   this._getExcelUnplanedByWorkenter(aExcelData,aDataSourceUnplannedByWorkcenter);
	
				// // Normal Service order operations
			    this._getExcelPodByWorkcenter(aExcelData,aDataSourcePerWorkcenter);
	
				// // Moved from today
			    this._getExcelChangedByWorkcenter(aExcelData,aDataSourceChangedTasksByWorkcenter);
			    
			    // this._getExcelNotificationsByWorkcenter(aExcelData,aDataSourceNotificationsByWorkcenter);
	
			} else if (selectedTab === 'TasksCustomerPoDKey') {
		        var aHeaderText = ['', 'TODAY`S PLANNED WORK BY CUSTOMER'];
				aExcelData.push(aHeaderText);
				
				if (this.getView().byId("customerList")) {
					var aSelectedCustomers = this.getView().byId("customerList").getSelectedItems();
					var aHeaderCText = ['', 'SELECTED CUSTOMERS			'];
					aSelectedCustomers.forEach(function(oCustomer) {
						aHeaderCText.push(oCustomer.getTitle());
					});
				}
				
				aExcelData.push(aHeaderCText);
					
				// // Unplanned tasks
			 //   this._getExcelUnplaned(aExcelData,oDataSourceUnplannedByCustomer);
	
				// Normal Service order operations
			    this._getExcelPod(aExcelData,oDataSourceByCustomer);
	
				// Moved from today
			    this._getExcelChanged(aExcelData,oDataSourceChangedTasksByCustomer);
			    
			    // this._getExcelNotifications(aExcelData,oDataSourceNotificationsByCustomer);
	
			} 

		    var oExcelSheet = XLSX.utils.aoa_to_sheet(aExcelData);

//---------------------------------------
		    var wscols = this._getColumnDefinition();
		    
			const worksheet = XLSX.utils.aoa_to_sheet(aExcelData);
			worksheet["!cols"] = wscols;
		
		// Test auto width:
		//const worksheet = XLSX.utils.aoa_to_sheet(arrayOfArray);
		//worksheet['!cols'] = fitToColumn(arrayOfArray);
		// worksheet['!cols'] = fitToColumn(aExcelData);
		
		// function fitToColumn(arrayOfArray) {
		//     // get maximum character of each column
		//     return arrayOfArray[0].map((a, i) => ({ wch: Math.max(...arrayOfArray.map(a2 => a2[i].toString().length)) }));
// }
//---------------------------------------

//		    oNewBook.Sheets["Daily Plan"] = oExcelSheet;
		    oNewBook.Sheets["Daily Plan"] = worksheet;
		
		    var oExcel = XLSX.write(oNewBook, {
		        bookType: 'xlsx',
		        type: 'binary'
		    });
		    
		    return oExcel;
		},
		
		_getColumnDefinition: function() {
			return [
		      { width: '12' },  // first column
		      { width: '40' }, // second column
		      { width: '40' },
		      { width: '30' },
		      { width: '30' },
		      { width: '20' },
		      { width: '40' },
		      { width: '15' }
		    ];
		},
		
		_getExcelNotifications: function(aExcelData,oDataSourceNotifications) {
			// Notifications + bundled tasks
		    var aExcelNotificationsData = [
		        ['','','', '', '',''], 
		        ['Open notifications:'], 
		        ['', 'Asset', 'Fault code - Description', 'Notification Nr./SO nr (bundles)', 'Workcenter', 'Team', 'Comments']
		    ]; //a row with 2 columns
		    
			for (var i=0; i<aExcelNotificationsData.length; i++) {
				aExcelData.push(aExcelNotificationsData[i]);
			}

			oDataSourceNotifications.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.FuncLocDesc , oItem.OperationText, oItem.OrderId, oItem.WorkcenterText, oItem.Team, oItem.Comments ];
				if (oItem.IsNotification === true) {
			    	aExcelData.push(aAssetExcelLine);

					
					oItem.BundledSO && oItem.BundledSO.forEach(function(oBundle) {
				    	var aBundledExcelLine = [ '', '' , oBundle.SOText, oBundle.OrderId + "/" + oBundle.OperationId, '', '', 'Bundled SO operation' ];
				    	aExcelData.push(aBundledExcelLine);
					});
				}
		    });
		},
		
		_getExcelNotificationsByWorkcenter: function(aExcelData,oDataSourceNotifications) {
			// Notifications + bundled tasks
		    var aExcelNotificationsData = [
		        ['','','', '', '',''], 
		        ['Open notifications:'], 
		        ['', 'Workcenter', 'Fault code - Description', 'Notification Nr./SO nr (bundles)', 'Asset', 'Team', 'Comments']
		    ]; //a row with 2 columns
		    
			for (var i=0; i<aExcelNotificationsData.length; i++) {
				aExcelData.push(aExcelNotificationsData[i]);
			}

			oDataSourceNotifications.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, oItem.OrderId, oItem.FuncLocDesc, oItem.Team, oItem.Comments ];
				if (oItem.IsNotification === true) {
			    	aExcelData.push(aAssetExcelLine);

					
					oItem.BundledSO && oItem.BundledSO.forEach(function(oBundle) {
				    	var aBundledExcelLine = [ '', '' , oBundle.SOText, oBundle.OrderId + "/" + oBundle.OperationId, '', '', 'Bundled SO operation' ];
				    	aExcelData.push(aBundledExcelLine);
					});
				}
		    });
		},
		
		_getExcelChanged: function(aExcelData,oDataSourceChangedTasks) {
			var aHeaderText = ['', 'TODAY`S CHANGES:			'];
			aExcelData.push(aHeaderText);

			// Changed tasks
		    var aExcelChangedTasks = [
		        ['','','', '', '',''], 
		        ['Changed Tasks - Scheduled service and Troubleshooting:'],
		        ['', 'Asset', 'Operation text', 'Service Order/Operation Nr.', 'Workcenter', 'Team', 'Comments', 'Date']
		    ]; //a row with 2 columns				

			for (var i=0; i<aExcelChangedTasks.length; i++) {
				aExcelData.push(aExcelChangedTasks[i]);
			}

			oDataSourceChangedTasks.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.FuncLocDesc , oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.WorkcenterText, oItem.Team, 
		    			oItem.Comments, oItem.EarliestStartDate ];
		    	aExcelData.push(aAssetExcelLine);
		    	var aChangedToExcelLine = [ '', '' , '', '                    CHANGED FROM ----->', oItem.OriginalWorkcenterText, oItem.OriginalTeam, '', oItem.OriginalEarliestStartDate ];
		    	aExcelData.push(aChangedToExcelLine);
		    });	
		},
		
		_getExcelChangedByWorkcenter: function(aExcelData,oDataSourceChangedTasks) {
			var aHeaderText = ['', 'TODAY`S CHANGES:			'];
			aExcelData.push(aHeaderText);

			// Changed tasks
		    var aExcelChangedTasks = [
		        ['','','', '', '',''], 
		        ['Changed Tasks - Scheduled service and Troubleshooting:'],
		        ['', 'Workcenter', 'Operation text', 'Service Order/Operation Nr.', 'Asset', 'Team', 'Comments', 'Date']
		    ]; //a row with 2 columns				

			for (var i=0; i<aExcelChangedTasks.length; i++) {
				aExcelData.push(aExcelChangedTasks[i]);
			}

			oDataSourceChangedTasks.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.FuncLocDesc, oItem.Team, 
		    			oItem.Comments, oItem.EarliestStartDate ];
		    	aExcelData.push(aAssetExcelLine);
		    	var aChangedToExcelLine = [ '', '' , '', '                    CHANGED FROM ----->', oItem.OriginalWorkcenterText, oItem.OriginalTeam, '', oItem.OriginalEarliestStartDate ];
		    	aExcelData.push(aChangedToExcelLine);
		    });	
		},
		
		_getExcelUnplaned: function(aExcelData,oDataSourceUnplanned) {
			var aExcelUnplannedTasks = [
		        ['','','', '', '',''], 
		        ['Unplanned tasks:'], 
		        ['', 'Asset', 'Description', '', 'Workcenter', 'Team', 'Comments']
		    ]; //a row with 2 columns

			for (var i=0; i<aExcelUnplannedTasks.length; i++) {
				aExcelData.push(aExcelUnplannedTasks[i]);
			}

			oDataSourceUnplanned.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.FuncLocDesc , oItem.OperationText, '', oItem.WorkcenterText, oItem.Team, oItem.Comment ];
		    	aExcelData.push(aAssetExcelLine);
		    });	
			
		},
		
		_getExcelUnplanedByWorkenter: function(aExcelData,oDataSourceUnplanned) {
			var aExcelUnplannedTasks = [
		        ['','','', '', '',''], 
		        ['Unplanned tasks:'], 
		        ['', 'Workcenter', 'Description', '', 'Asset', 'Team', 'Comments']
		    ]; //a row with 2 columns

			for (var i=0; i<aExcelUnplannedTasks.length; i++) {
				aExcelData.push(aExcelUnplannedTasks[i]);
			}

			oDataSourceUnplanned.forEach(function(oItem) {
		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, '', oItem.FuncLocDesc, oItem.Team, oItem.Comment ];
		    	aExcelData.push(aAssetExcelLine);
		    });	
			
		},
		
		_getExcelPod: function(aExcelData,oDataSource) {
			var aExcelServiceOrderOperationsData = [
		        ['','','', '', '',''], 
		        ['Scheduled service and Troubleshooting:'], 
//		        ['', 'Asset', 'Operation text', 'Service Order/Operation Nr.', 'Workcenter', 'Team', 'Comments']
		        ['', 'Asset', 'Operation text', 'Service Order/Operation Nr.', 'Workcenter', 'Team', 'Comments', 'Date']
		    ]; //a row with 2 columns

			for (var i=0; i<aExcelServiceOrderOperationsData.length; i++) {
				aExcelData.push(aExcelServiceOrderOperationsData[i]);
			}
		    
		    oDataSource.forEach(function(oItem) {
//		    	var aAssetExcelLine = [ '', oItem.FuncLocDesc , oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.WorkcenterText, oItem.Team, oItem.Comments ];
		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.FuncLocDesc, oItem.Team, 
		    			oItem.Comments, oItem.EarliestStartDate ];
				if (oItem.IsNotification === false) {
			    	aExcelData.push(aAssetExcelLine);
			}
		    });	
		},
		
		_getExcelPodByWorkcenter: function(aExcelData,oDataSource) {
			var aExcelServiceOrderOperationsData = [
		        ['','','', '', '',''], 
		        ['Scheduled service and Troubleshooting:'], 
//		        ['', 'Workcenter', 'Operation text', 'Service Order/Operation Nr.', 'Asset', 'Team', 'Comments']
		        ['', 'Workcenter', 'Operation text', 'Service Order/Operation Nr.', 'Asset', 'Team', 'Comments', 'Date']
		    ]; //a row with 2 columns

			for (var i=0; i<aExcelServiceOrderOperationsData.length; i++) {
				aExcelData.push(aExcelServiceOrderOperationsData[i]);
			}
		    
		    oDataSource.forEach(function(oItem) {
//		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.FuncLocDesc, oItem.Team, oItem.Comments ];
		    	var aAssetExcelLine = [ '', oItem.WorkcenterText, oItem.OperationText, oItem.OrderId + "/" + oItem.OperationId, oItem.FuncLocDesc, oItem.Team, 
		    	oItem.Comments, oItem.EarliestStartDate ];
				if (oItem.IsNotification === false) {
			    	aExcelData.push(aAssetExcelLine);
			}
		    });	
		},
		
		_onExportToPdf: function (oController) {
   			var oViewModel = this.getView().getModel("viewModel");
			var dCurrentDate = oViewModel.getProperty("/Data/TodaysDate");
			var sFileCurrentDate = moment(dCurrentDate).format("YYYY-MM-DD");		

			var pdfName = "Plan of Day " + sFileCurrentDate + ".pdf";
			var that = this;
			
			jsPDF.autoTableSetDefaults({
		        columnStyles: {id: {fontStyle: 'bold'}},
		        headStyles: {fillColor: 0},
		    });
		
		    var oDoc = new jsPDF('l', 'pt', 'a4', false);
		    
			// Site Settings and date info
			var sSiteName = oViewModel.getProperty("/UserSettings/SiteName");
			var aSites = oViewModel.getProperty("/UserSettings/Sites");
			var sCurrentDate = moment(dCurrentDate).format("MMM DD, YYYY");
			var sHeaderText;

			// branch out to different scenarios
			var oViewModel = this.getView().getModel("viewModel");
			var selectedTab = oViewModel.getProperty("/Data/ServiceOperationsFromDateRange/selectedTab");

//-----------------------------		
			// Function Locations
		    // oDoc.autoTable({head: that._getSettingsFuncLocHeadRows(), body: that._getSettingsFuncLocBodyRows()});

			// Workcenters
//		    oDoc.autoTable({head: that._getSettingsWorkcenterHeadRows(), body: that._getSettingsWorkcenterBodyRows()});
//-----------------------------		

			if (selectedTab === undefined || selectedTab === 'EditPoDKey' || selectedTab === 'ViewPoDKey') {
				
				sHeaderText = "Plan of Day for " + sCurrentDate + ". Site name: " + sSiteName; 
	
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text(sHeaderText, data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getSettingsFuncLocHeadRows(), body: that._getSettingsFuncLocBodyRows(),
			    	styles: {fontSize: 8}
			    });

				// --- Unplanned tasks ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Unplanned Tasks', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODUnplannedHeadRows(), body: that._getPODUnplannedBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
				// --- Scheduled Service ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
	//		        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Scheduled service and Troubleshooting', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODHeadRows(), body: that._getPODBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
					// oDoc.text(10, oDoc.lastAutoTable.finalY + 50, "test text...");
	
			    // oDoc.addPage();
			    
				// --- Moved from today ---
				
				oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Moved from Today', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODMovedHeadRows(), body: that._getPODMovedBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
			    oDoc.addPage();
	
				// Open Notifications
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Open Notifications', data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getNotifHeadRows(), body: that._getNotifBodyRows(), 
			    	styles: {fontSize: 8}
			    });
	
			    // oDoc.addPage();
			    
			} else if (selectedTab === 'ChangedTasksPoDKey'){
				
				sHeaderText = "Moved from Today for " + sCurrentDate + ". Site name: " + sSiteName; 
	
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text(sHeaderText, data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getSettingsFuncLocHeadRows(), body: that._getSettingsFuncLocBodyRows(), 
			    styles: {fontSize: 8}});
				
				// --- Changed tasks ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Scheduled service and Troubleshooting', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODChangedHeadRows(), body: that._getPODChangedBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    	
			    
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Open Notifications', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getNotifHeadRows(), body: that._getNotifBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			} else if (selectedTab === 'TasksWorkcenterPoDKey'){
				
				sHeaderText = "Plan of Day for " + sCurrentDate + ". Site name: " + sSiteName; 
	
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text(sHeaderText, data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getSettingsFuncLocHeadRows(), body: that._getSettingsFuncLocBodyRows(),
			    	styles: {fontSize: 8}
			    });

				// --- Unplanned tasks ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Unplanned Tasks', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODUnplannedByWorkcenterHeadRows(), body: that._getPODUnplannedByWorkcenterBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
				// --- Scheduled Service ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
	//		        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Scheduled service and Troubleshooting', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODByWorkcenterHeadRows(), body: that._getPODByWorkcenterBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
					// oDoc.text(10, oDoc.lastAutoTable.finalY + 50, "test text...");
	
			    // oDoc.addPage();
			    
				// --- Moved from today ---
				
				oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Moved from Today', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODMovedByWorkcenterHeadRows(), body: that._getPODMovedByWorkcenterBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
			    oDoc.addPage();
	
				// Open Notifications
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Open Notifications', data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getNotifByWorkcenterHeadRows(), body: that._getNotifByWorkcenterBodyRows(), 
			    	styles: {fontSize: 8}
			    });
			} else if (selectedTab === 'TasksCustomerPoDKey'){
				
				sHeaderText = "Plan of Day for " + sCurrentDate + ". Site name: " + sSiteName; 
	
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text(sHeaderText, data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getSettingsFuncLocHeadRows(), body: that._getSettingsFuncLocBodyRows(),
			    	styles: {fontSize: 8}
			    });

				// --- Unplanned tasks ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Unplanned Tasks', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODUnplannedByCustomerHeadRows(), body: that._getPODUnplannedByCustomerBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
				// --- Scheduled Service ---
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
	//		        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Scheduled service and Troubleshooting', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODByCustomerHeadRows(), body: that._getPODByCustomerBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
					// oDoc.text(10, oDoc.lastAutoTable.finalY + 50, "test text...");
	
			    // oDoc.addPage();
			    
				// --- Moved from today ---
				
				oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Moved from Today', data.settings.margin.left, 
			            	oDoc.lastAutoTable.finalY + 50);
			        }
			    });
	
			    oDoc.autoTable({head: that._getPODMovedByCustomerHeadRows(), body: that._getPODMovedByCustomerBodyRows(), 
			    	startY: oDoc.lastAutoTable.finalY + 70, styles: {fontSize: 8} });
			    
			    oDoc.addPage();
	
				// Open Notifications
			    oDoc.autoTableSetDefaults({
			        headStyles: {fillColor: [176, 223, 229]}, // Purple
			        margin: {top: 75},
			        didDrawPage: function(data) {
			            oDoc.setFontSize(20);
			            oDoc.text('Open Notifications', data.settings.margin.left, 50);
			        }
			    });
			    
			    oDoc.autoTable({head: that._getNotifByCustomerHeadRows(), body: that._getNotifByCustomerBodyRows(), 
			    	styles: {fontSize: 8}
			    });
			}
			
			oDoc.autoTableSetDefaults(null);
	        jsPDF.autoTableSetDefaults(null);
	        
	        oDoc.save(pdfName);
			
		},

		_getSettingsWorkcenterHeadRows: function() {
   			var oViewModel = this.getView().getModel("viewModel");
			var sSiteName = oViewModel.getProperty("/UserSettings/SiteName");
			var aWorkcenters = oViewModel.getProperty("/UserSettings/Workcenters");
//			var aSites = oViewModel.getProperty("/UserSettings/Sites");
			var dCurrentDate =  oViewModel.getProperty("/Data/TodaysDate");

//			return [{Description: "Function Location ID", Name: "Function Location description"}];
			return [{Description: "Site information - Workcenter IDs"}];
//			return ["Site information - Function Location IDs"];
		},

		_getSettingsWorkcenterBodyRows: function() {
   			var oViewModel = this.getView().getModel("viewModel");
			var aWorkcenters = oViewModel.getProperty("/UserSettings/Workcenters");

			var rows = [];
			var strucWorkcenter = {
				Description: ""
			}

			var sWorkcentersAll = "";
			for (var i=0; i<aWorkcenters.length;i++) {
				if (i>0) {
					sWorkcentersAll = sWorkcentersAll + ", " + aWorkcenters[i].WorkcenterId;
				} else {
					sWorkcentersAll = aWorkcenters[i].WorkcenterId;
				}
			}

			strucWorkcenter.Description = sWorkcentersAll;
			rows.push(strucWorkcenter);
			return rows;
		},

		_getSettingsFuncLocHeadRows: function() {
   			var oViewModel = this.getView().getModel("viewModel");
			var sSiteName = oViewModel.getProperty("/UserSettings/SiteName");
			var aSites = oViewModel.getProperty("/UserSettings/Sites");
			var dCurrentDate =  oViewModel.getProperty("/Data/TodaysDate");

//			return [{Description: "Function Location ID", Name: "Function Location description"}];
			return [{Description: "Site information - Function Location IDs"}];
//			return ["Site information - Function Location IDs"];
		},

		_getSettingsFuncLocBodyRows: function() {
   			var oViewModel = this.getView().getModel("viewModel");
			var aSites = oViewModel.getProperty("/UserSettings/Sites");
			var rows = [];
			var strucFuncLoc = {
				Description: ""
			}

			var sFuncLocAll = "";
			for (var i=0; i<aSites.length;i++) {
				if (i>0) {
					sFuncLocAll = sFuncLocAll + ", " + aSites[i];
				} else {
					sFuncLocAll = aSites[i];
				}
			}

			strucFuncLoc.Description = sFuncLocAll;
			rows.push(strucFuncLoc);
			return rows;
		},
		
		_getPODHeadRows: function() {
			return [{FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer'}];
		},
		
		_getPODBodyRows: function() {
			var oTable = this.getView().byId("PODTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var aTableData = _.cloneDeep(oTable);
			return _.filter(aTableData, { IsNotification: false });
		},
		
		_getPODUnplannedHeadRows: function() {
			return [{FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer'}];
		},
		
		_getPODUnplannedBodyRows: function() {
			var oTable = this.getView().byId("UnplannedTable").getModel("viewModel").getProperty("/Data/UnplannedForToday");
			var aTableData = _.cloneDeep(oTable);
			return aTableData;
		},
		
		_getPODUnplannedByWorkcenterHeadRows: function() {
			return [{WorkcenterText: 'Workcenter', FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer'}];
		},
		
		_getPODUnplannedByWorkcenterBodyRows: function() {
			var oTable = this.getView().byId("unplanedWorkcenterTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			return aTableData;
		},
		
		_getPODUnplannedByCustomerHeadRows: function() {
			return [{CustomerText: 'Customer', FuncLocDesc: 'Asset', WorkcenterText: 'Workcenter', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments'}];
		},
		
		_getPODUnplannedByCustomerBodyRows: function() {
			var oTable = this.getView().byId("unplanedCustomerTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			return aTableData;
		},
		
		_getPODMovedHeadRows: function() {
			return [{FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer', MoveReason: 'Reason for move'}];
		},
		
		_getPODMovedBodyRows: function() {
			var oTable = this.getView().byId("MovedTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/movedFromDay");
			var aTableData = _.cloneDeep(oTable);
			return aTableData;
		},
		
		_getPODMovedByWorkcenterHeadRows: function() {
			return [{WorkcenterText: 'Workcenter', FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer', MoveReason: 'Reason for move'}];
		},
		
		_getPODMovedByWorkcenterBodyRows: function() {
			var oTable = this.getView().byId("movedWorkcenterTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			return aTableData;
		},
		
		_getPODMovedByCustomerHeadRows: function() {
			return [{CustomerText: 'Customer', FuncLocDesc: 'Asset', WorkcenterText: 'Workcenter', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', MoveReason: 'Reason for move'}];
		},
		
		_getPODMovedByCustomerBodyRows: function() {
			var oTable = this.getView().byId("movedCustomerTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			return aTableData;
		},
		
		_getPODChangedHeadRows: function() {
			return [{FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer', MoveReason: 'Reason for move', EarliestStartDate: 'Moved From', OriginalEarliestStartDate: 'Moved To'}];
		},
		
		_getPODChangedBodyRows: function() {
			var oTable = this.getView().byId("ChangedTaskTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/changedFromDay");
			var aTableData = _.cloneDeep(oTable);
			aTableData && aTableData.forEach(function(oData) {
				oData.EarliestStartDate ? oData.EarliestStartDate = oData.EarliestStartDate.toDateString() : undefined;
				oData.OriginalEarliestStartDate ? oData.OriginalEarliestStartDate = oData.OriginalEarliestStartDate.toDateString() : undefined;
			})
			return aTableData;
		},
		
		_getPODByWorkcenterHeadRows: function() {
			return [{WorkcenterText: 'Workcenter', FuncLocDesc: 'Asset', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', CustomerText: 'Customer', MoveReason: 'Reason for move', EarliestStartDate: 'Moved From', OriginalEarliestStartDate: 'Moved To'}];
		},
		
		_getPODByWorkcenterBodyRows: function() {
			var oTable = this.getView().byId("podWorkcenterTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			aTableData && aTableData.forEach(function(oData) {
				oData.EarliestStartDate ? oData.EarliestStartDate = oData.EarliestStartDate.toDateString() : undefined;
				oData.OriginalEarliestStartDate ? oData.OriginalEarliestStartDate = oData.OriginalEarliestStartDate.toDateString() : undefined;
			})
			return aTableData;
		},
		
		_getPODByCustomerHeadRows: function() {
			return [{CustomerText: 'Customer', FuncLocDesc: 'Asset', WorkcenterText: 'Workcenter', OperationText: 'Operation Text', OrderId: 'Service Order', OperationId: 'Operation Nr.', Team: 'Team', Comments: 'Comments', MoveReason: 'Reason for move', EarliestStartDate: 'Moved From', OriginalEarliestStartDate: 'Moved To'}];
		},
		
		_getPODByCustomerBodyRows: function() {
			var oTable = this.getView().byId("podCustomerTable").getItems();
			var oTableData = _.cloneDeep(oTable);
			
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			aTableData && aTableData.forEach(function(oData) {
				oData.EarliestStartDate ? oData.EarliestStartDate = oData.EarliestStartDate.toDateString() : undefined;
				oData.OriginalEarliestStartDate ? oData.OriginalEarliestStartDate = oData.OriginalEarliestStartDate.toDateString() : undefined;
			})
			return aTableData;
		},

		_getNotifHeadRows: function() {
			return [{FuncLocDesc: 'Asset', OperationText: 'Fault code - Description', OrderId: 'Notification Nr.', Team: 'Team', Comments: 'Comments'}];
		},
		
		_getNotifBodyRows: function() {
			var oTable = this.getView().byId("PODNotificationsTable").getModel("viewModel").getProperty("/Data/ServiceOperationsFromDateRange/potd");
			var aTableData = _.cloneDeep(oTable);
			var aNotifications = _.filter(aTableData, { IsNotification: true });
			var aNotificationsWithBundled = _.cloneDeep(aNotifications);
			aNotifications && aNotifications.forEach(function(oNotification,i) {
				if (oNotification.BundledSO) {
					oNotification.BundledSO.forEach(function(oSOBundled,j) {
						var oNewSO = {};
						oNewSO.FuncLocDesc = "Bundled SO";
						oNewSO.OperationText = oSOBundled.SOText;
						oNewSO.OrderId = oSOBundled.OrderId + oSOBundled.OperationId;
						oNewSO.Team = " ";
						oNewSO.Comments = " ";
						var iIndex = _.findIndex(aNotificationsWithBundled, { OrderId: oNotification.OrderId });
						aNotificationsWithBundled.splice(iIndex+j+1, 0, oNewSO);
					});
				}
			});
			return aNotificationsWithBundled;
			// return _.filter(aTableData, { IsNotification: true });
		},
		
		_getNotifByWorkcenterHeadRows: function() {
			return [{WorkcenterText: 'Workcenter', FuncLocDesc: 'Asset', OperationText: 'Fault code - Description', OrderId: 'Notification Nr.', Team: 'Team', Comments: 'Comments'}];
		},
		
		_getNotifByWorkcenterBodyRows: function() {
			var oTable = this.getView().byId("NotificationWorkcenterTable").getItems();
			
			var oTableData = _.cloneDeep(oTable);
			
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var aNotifications = _.filter(aTableData, { IsNotification: true });
			var aNotificationsWithBundled = _.cloneDeep(aNotifications);
			aNotifications && aNotifications.forEach(function(oNotification,i) {
				if (oNotification.BundledSO) {
					oNotification.BundledSO.forEach(function(oSOBundled,j) {
						var oNewSO = {};
						oNewSO.FuncLocDesc = "Bundled SO";
						oNewSO.OperationText = oSOBundled.SOText;
						oNewSO.OrderId = oSOBundled.OrderId + oSOBundled.OperationId;
						oNewSO.Team = " ";
						oNewSO.Comments = " ";
						var iIndex = _.findIndex(aNotificationsWithBundled, { OrderId: oNotification.OrderId });
						aNotificationsWithBundled.splice(iIndex+j+1, 0, oNewSO);
					});
				}
			});
			return aNotificationsWithBundled;
			// return _.filter(aTableData, { IsNotification: true });
		},
		
		_getNotifByCustomerHeadRows: function() {
			return [{CustomerText: 'Customer', FuncLocDesc: 'Asset', WorkcenterText: 'Workcenter', OperationText: 'Fault code - Description', OrderId: 'Notification Nr.', Team: 'Team', Comments: 'Comments'}];
		},
		
		_getNotifByCustomerBodyRows: function() {
			var oTable = this.getView().byId("NotificationCustomerTable").getItems();
			
			var oTableData = _.cloneDeep(oTable);
			
			var aTableData = [];
			oTableData && oTableData.forEach(function(oItem) {
				aTableData.push(oItem.getBindingContext("viewModel").getObject());
			});
			
			var aNotifications = _.filter(aTableData, { IsNotification: true });
			var aNotificationsWithBundled = _.cloneDeep(aNotifications);
			aNotifications && aNotifications.forEach(function(oNotification,i) {
				if (oNotification.BundledSO) {
					oNotification.BundledSO.forEach(function(oSOBundled,j) {
						var oNewSO = {};
						oNewSO.FuncLocDesc = "Bundled SO";
						oNewSO.OperationText = oSOBundled.SOText;
						oNewSO.OrderId = oSOBundled.OrderId + oSOBundled.OperationId;
						oNewSO.Team = " ";
						oNewSO.Comments = " ";
						var iIndex = _.findIndex(aNotificationsWithBundled, { OrderId: oNotification.OrderId });
						aNotificationsWithBundled.splice(iIndex+j+1, 0, oNewSO);
					});
				}
			});
			return aNotificationsWithBundled;
			// return _.filter(aTableData, { IsNotification: true });
		},
		
		_isSet: function(sValue) {
			return Array.isArray(sValue) && sValue.length > 0 || !Array.isArray(sValue) && sValue ? true : false;
		},
		_isNotSet: function(sValue) {
			return !this._isSet(sValue);
		},
		_canMoveFormatter: function(bMove, dDate, bRemove, bClear) {
			return (bMove && dDate) || bRemove || bClear ? true : false;
		},
		_canMoveAllFormatter: function(dDate) {
			return dDate ? true : false;
		},
		_canBTnMoveAllFormatter: function(aPotd) {
			return aPotd && aPotd.length > 0 ? true : false;
		},
		handleRemoveTeamMember: function(oEvent) {
			var oChanged = this._removeTeamMember(oEvent);
			
			var oViewModel = this.getView().getModel("viewModel");
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId);
			oLocalChanges.Team = oChanged.Team;
			DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId, oLocalChanges)
				.then(function() {DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"))}.bind(this));
		},
		
		handleUnplannedRemoveTeamMember: function(oEvent) {
			var oChanged = this._removeTeamMember(oEvent);
			this._saveUnplanned(oChanged);
		},
		
		_removeTeamMember: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			var oViewModel = oContext.getModel();
			var oServiceOperation = oContext.getObject();
			
			var aRemoved = _.map(oEvent.getParameter("removedTokens"), function(oToken) { return oToken.getBindingContext("viewModel").getObject(); });
			var aNewValue = _.differenceBy(oContext.getProperty("TeamArray"), aRemoved, 'Initials');
			
			oServiceOperation.Team = _.map(aNewValue, 'Initials').join(", ");
			
			return oServiceOperation;
		},
		
		handleAddTeamMember: function(oEvent) {
			var oChanged = this._addTeamMember(oEvent);
			
			var oViewModel = this.getView().getModel("viewModel");
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId);
			oLocalChanges.Team = oChanged.Team;
			DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oChanged.OrderId, oChanged.OperationId, oLocalChanges)
				.then(function() {DataHandler.reloadWeeklyServiceOperations(this.getView().getModel("viewModel"), this.getView().getModel("backend"))}.bind(this));
		},
		
		handleUnplannedAddTeamMember: function(oEvent) {
			var oChanged = this._addTeamMember(oEvent);
			this._saveUnplanned(oChanged);
		},
		
		_addTeamMember: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			var oViewModel = oContext.getModel();
			var oChanged = oContext.getObject();

			oChanged.Team = [..._.map(oContext.getProperty("TeamArray"), 'Initials'), oEvent.getParameter("value")].join(", ");
			
			return oChanged;
		},
		
		handleAddComment: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			var oViewModel = oContext.getModel();
			var oServiceOperation = oContext.getObject();
			var oInput = _.cloneDeep(oEvent);
			
			var oLocalChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId);
			oLocalChanges.Comments = oEvent.getParameter("newValue");
			DataHandler
				.saveLocalChangesForServiceOperation(oViewModel, oServiceOperation.OrderId, oServiceOperation.OperationId, oLocalChanges)
				.then(function() {
					oInput.getSource().focus();
				});
		},
		
		handleAddCommentToNotif: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("viewModel");
			var oViewModel = oContext.getModel();
			var oServiceOperation = oContext.getObject();
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oServiceOperation.OrderId);
			
			oLocalNotifChanges.Comments = oEvent.getParameter("newValue");
			DataHandler
				.saveLocalChangesForNotification(oViewModel, oServiceOperation, oLocalNotifChanges)
		},
		
		_setBubbleClass: function(aList) {
			aList && aList.length > 0 ? this.getView().byId("notificationBtn").addStyleClass("bubble") : 
										this.getView().byId("notificationBtn").removeStyleClass("bubble");
			return " ";
		},
		
		_setBubbleClassInc: function(aList) {
			aList && aList.length > 0 ? this.getView().byId("incompleteBtn").addStyleClass("bubble") : 
										this.getView().byId("incompleteBtn").removeStyleClass("bubble");
			return " ";
		},
		
	});
}, /* bExport= */ true);
