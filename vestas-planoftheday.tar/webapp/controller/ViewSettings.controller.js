sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/DataHandler"
], function (Controller, DataHandler) {
	"use strict";

	return Controller.extend("plancalendar.controller.ViewSettings", {
		
		oResourceModel: null,
		
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("ViewSettings").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
		},
		
		handleRouteMatched: function(oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			var bIsInitialized = oViewModel.getProperty("/IsDataInitialized");
			var oComponent = this.getOwnerComponent();
			this.oResourceModel = oComponent.getModel("i18n").getResourceBundle();
			
			if (!bIsInitialized) {
				DataHandler.initializeData(this.getView()).then(function(bResult) {
					if (!bResult) {
						this.oRouter.navTo("Settings");
					}
				}.bind(this));
			} else {
				oViewModel.updateBindings(true);
			}
			oViewModel.setProperty("/ApplicationBusy", false);
		},
		
		_onClearPress: function(oEvent) {
			DataHandler.clearSettings();
		},
		
		_onDelete: function(oEvent) {
			var oSite = oEvent.getSource().getBindingContext("viewModel").getObject();
			var oViewModel = this.getView().getModel("viewModel");
			sap.m.MessageBox.confirm(
				"Are you sure you want to delete site '" + oSite.SiteName + "'?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							var oUserSettings = oViewModel.getProperty("/UserSettings");
							var iIndex = _.findIndex(oUserSettings.SavedSites, { SiteId: oSite.SiteId });
							if (iIndex >= 0) {
								oUserSettings.SavedSites.splice(iIndex, 1);
							}
							DataHandler.saveSettings(oUserSettings).then(function() {
								oViewModel.updateBindings(true);
							}.bind(this));
						}
					}.bind(this)
				}
			);
		},
		
		_onAdd: function(oEvent) {
			this.oRouter.navTo("Settings", { id: "new" });
		},
		
		_onEdit: function(oEvent) {
			this.oRouter.navTo("Settings", { id: oEvent.getSource().getBindingContext("viewModel").getProperty("SiteId") });
		},
		
		_onNavigateToPotd: function(oEvent) {
			oEvent.getSource().getModel("viewModel").setProperty("/ApplicationBusy", true);
			setTimeout(function() {
				this.oRouter.navTo("DayView");
			}.bind(this), 100);
		},
		
		_formatWorkcenters: function(aWorkcenters) {
			return _.map(aWorkcenters, function(oWorkcenter) { return oWorkcenter.WorkcenterText + " (" + oWorkcenter.WorkcenterId  + ")";}).join(", ");
		},
		
		_onSavedSitesChange: function(oEvent) {
			var oSavedSite = oEvent.getSource().getBindingContext("viewModel").getObject();
			if (oSavedSite && !oSavedSite.LocalChanges) {
				oSavedSite.LocalChanges = {};
			}
			var oViewModel = this.getView().getModel("viewModel");
			if (oSavedSite) {
				var aSavedSites = oViewModel.getProperty("/UserSettings/SavedSites");
				var iIndex = _.findIndex(aSavedSites, { SiteId: oViewModel.getProperty("/UserSettings/SiteId")});
				var oOldSavedSite = aSavedSites[iIndex];
				if (oOldSavedSite) {
					oOldSavedSite.LocalChanges = oViewModel.getProperty("/UserSettings/LocalChanges");
					aSavedSites.splice(iIndex, 1, oOldSavedSite);
				}
				
				oViewModel.setProperty("/UserSettings/SiteId", oSavedSite.SiteId);
				oViewModel.setProperty("/UserSettings/SiteName", oSavedSite.SiteName);
				oViewModel.setProperty("/UserSettings/Sites", oSavedSite.Sites);
				oViewModel.setProperty("/UserSettings/Workcenters", oSavedSite.Workcenters);
				oViewModel.setProperty("/UserSettings/HoursPerDay", oSavedSite.HoursPerDay);
				oViewModel.setProperty("/UserSettings/SavedSites", aSavedSites);
				oViewModel.setProperty("/UserSettings/LocalChanges", oSavedSite.LocalChanges);
				DataHandler.saveSettings(oViewModel.getProperty("/UserSettings")).then(function() {
					DataHandler.initializeData(this.getView());
				}.bind(this))
			}
		}
	});

});