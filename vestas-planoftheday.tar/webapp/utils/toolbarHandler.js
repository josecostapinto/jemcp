sap.ui.define([
	"../libs/lodash.min",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../model/DataHandler"
], function(NameToAvoidNamingConflictsLodash,MessageToast,Fragment,DataHandler) {
    "use strict";

    return {
    	onIncompletePress: function(oEvent,controller) {
			var oView = controller.getView();
			var oButton = oEvent.getSource();

			if (!controller._oIncompletePopover) {
				Fragment.load({
					id: oView.getId(),
					name: "plancalendar.view.IncompleteTasks"
				}).then(function (oPopover) {
					controller._oIncompletePopover = oPopover;
					oView.addDependent(controller._oIncompletePopover);
					controller._oIncompletePopover.openBy(oButton);
				}.bind(controller));
			} else {
				if (controller._oIncompletePopover.isOpen()) {
					controller._oIncompletePopover.close();
				} else {
					controller._oIncompletePopover.openBy(oButton);
				}
			}
		},
		
		onNotificationsPress: function(oEvent,controller) {
			var oView = controller.getView();
			var oButton = oEvent.getSource();

			if (!controller._oPopover) {
				Fragment.load({
					id: oView.getId(),
					name: "plancalendar.view.Notifications", 
					controller: controller
				}).then(function (oPopover) {
					controller._oPopover = oPopover;
					oView.addDependent(controller._oPopover);
					controller._oPopover.openBy(oButton);
				}.bind(controller));
			} else {
				if (controller._oPopover.isOpen()) {
					controller._oPopover.close();
				} else {
					controller._oPopover.openBy(oButton);
				}
			}
		},
		
		onAcceptPress: function(oEvent,controller) {
			var oView = controller.getView();
			var oButton = oEvent.getSource();
			var oViewModel = oButton.getBindingContext("viewModel").getModel();
			var oNotification = oEvent.getSource().getBindingContext("viewModel").getObject();
			var oLocalNotifChanges = DataHandler.getLocalChangesForNotifications(oViewModel, oNotification.NotificationId);
			var oLocalSOChanges = DataHandler.getLocalChangesForServiceOperation(oViewModel, oNotification.NotificationId);
			oLocalNotifChanges.EarliestStartDate = new Date(oViewModel.getProperty("/Data/TodaysDate"));
			
			DataHandler
				.saveLocalChangesForNotification(oViewModel, oNotification, oLocalNotifChanges)
				.then(function() {
					DataHandler._mapNotification(oLocalSOChanges,oNotification,oLocalNotifChanges);
					DataHandler.saveLocalChangesForServiceOperation(oViewModel, oNotification.NotificationId, "0000", oLocalSOChanges);
					DataHandler.reloadWeeklyServiceOperations(controller.getView().getModel("viewModel"), controller.getView().getModel("backend"));
				}.bind(controller),
				MessageToast.show(controller.oResourceModel.getText("notificationAddedTxt")));
		},
    	
    	
    };
});