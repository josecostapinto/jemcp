  /*global moment, _ */
sap.ui.define([
	"../libs/lodash.min"
], function(NameToAvoidNamingConflictsLodash) {
    "use strict";

    return {
     	generateUniqueId: function() {
			// https://gist.github.com/gordonbrander/2230317
			return '_' + Math.random().toString(36).substr(2, 9);
		}
    };
});
   	
    			
		
		